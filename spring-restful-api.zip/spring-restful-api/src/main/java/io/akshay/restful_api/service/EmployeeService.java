package io.akshay.restful_api.service;

import java.util.List;

import io.akshay.restful_api.entity.Employee;

public interface EmployeeService {

	List<Employee> findAll();

	Employee findOne(String empId);

	Employee create(Employee employee);

	Employee update(String empId, Employee employee);

	void delete(String id);
}
