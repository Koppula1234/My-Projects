package io.akshay.restful_api.constants;

public final class URI {

	public static final String EMPLOYEES = "employees";
	
	public static final String ID = "{id}"; 
}
