package io.akshay.restful_api.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import io.akshay.restful_api.entity.Employee;
import io.akshay.restful_api.repository.EmployeeRepository;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Employee> findAll() {
		TypedQuery<Employee> query = em.createNamedQuery("Employee.findAll", Employee.class);
		return query.getResultList();
	}

	@Override
	public Employee findOne(String empId) {
		return em.find(Employee.class, empId);
	}

	@Override
	public Employee create(Employee employee) {
		em.persist(employee);
		return employee;
	}

	@Override
	public Employee update(Employee employee) {
		return em.merge(employee);
	}

	@Override
	public void delete(Employee employee) {
		em.remove(employee);
	}

	@Override
	public String findByEmail(String email) {
		TypedQuery<Employee> query = em.createNamedQuery("Employee.findByEmail", Employee.class);
		query.setParameter("pEmail", email);
		List<Employee> list = query.getResultList();
		if (list.isEmpty()) {
			return null;
		}
		return list.get(0).getEmail();
	}

}
