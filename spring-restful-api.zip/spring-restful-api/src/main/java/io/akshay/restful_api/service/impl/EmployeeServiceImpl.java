package io.akshay.restful_api.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.akshay.restful_api.entity.Employee;
import io.akshay.restful_api.exceptions.BadRequestException;
import io.akshay.restful_api.exceptions.NotFoundException;
import io.akshay.restful_api.repository.EmployeeRepository;
import io.akshay.restful_api.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository employeerepository;

	public EmployeeServiceImpl(EmployeeRepository employeerepository) {
		this.employeerepository = employeerepository;

	}

	@Override
	@Transactional(readOnly = true)
	public List<Employee> findAll() {
		return employeerepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Employee findOne(String empId) {
		Employee existing = employeerepository.findOne(empId);
		if (existing == null) {
			throw new NotFoundException("Employee with id " + empId + " does not exist");
		}
		return existing;
	}

	@Override
	@Transactional
	public Employee create(Employee employee) {
		String existing = employeerepository.findByEmail(employee.getEmail());
		if (existing != null) {
			throw new BadRequestException("Employee with email " + employee.getEmail() + " already exists");
		}
		return employeerepository.create(employee);
	}

	@Override
	@Transactional
	public Employee update(String empId, Employee employee) {
		Employee existing = employeerepository.findOne(empId);
		if (existing == null) {
			throw new NotFoundException("Employee with id " + empId + " does not exist");
		}
		return employeerepository.update(employee);
	}

	@Override
	@Transactional
	public void delete(String empId) {
		Employee existing = employeerepository.findOne(empId);
		if (existing == null) {
			throw new NotFoundException("Employee with id " + empId + " does not exist");
		}
		employeerepository.delete(existing);
	}

}
