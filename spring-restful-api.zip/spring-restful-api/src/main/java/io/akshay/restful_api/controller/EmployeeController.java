package io.akshay.restful_api.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.akshay.restful_api.constants.URI;
import io.akshay.restful_api.entity.Employee;
import io.akshay.restful_api.service.EmployeeService;

@RestController
@RequestMapping(value = URI.EMPLOYEES)
public class EmployeeController {

	private EmployeeService employeeservice;

	public EmployeeController(EmployeeService employeeservice) {
		this.employeeservice = employeeservice;
	}

	@RequestMapping(method = RequestMethod.GET)
	public List<Employee> findAll() {
		return employeeservice.findAll();
	}

	@RequestMapping(method = RequestMethod.GET, value = URI.ID)
	public Employee findOne(@PathVariable("id") String empId) {
		return employeeservice.findOne(empId);
	}

	@RequestMapping(method = RequestMethod.POST)
	public Employee create(@RequestBody Employee employee) {
		return employeeservice.create(employee);
	}

	@RequestMapping(method = RequestMethod.PUT, value = URI.ID)
	public Employee update(@PathVariable("id") String empId, @RequestBody Employee employee) {
		return employeeservice.update(empId, employee);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = URI.ID)
	public void delete(@PathVariable("id") String id) {
		employeeservice.delete(id);
	}
}
