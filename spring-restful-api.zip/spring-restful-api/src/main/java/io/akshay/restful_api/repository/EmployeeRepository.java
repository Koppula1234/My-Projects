package io.akshay.restful_api.repository;

import java.util.List;

import io.akshay.restful_api.entity.Employee;

public interface EmployeeRepository {

	List<Employee> findAll();

	Employee findOne(String empId);

	Employee create(Employee employee);

	Employee update(Employee employee);

	void delete(Employee employee);
	
	String findByEmail(String email);
}
