﻿$(document).ready(function ()
{
  //add class based on device window width
  var current_width = $(window).width();

  if (current_width < 750)
  {
    $("nav#topMenu").addClass("navbar navbar-inverse navbar-fixed-top");
  }
  else
  {
    $("nav#topMenu").addClass("navbar navbar-default navbar-fixed-top");
  }

    //set focus of username input field when logging in
  $("#signin").click(function () {  });
  
  function setFocus() {
      document.getElementById('<% username.ClientID %>').focus();
  }


  //image hover for main team function
  $(".img-zoom").hover(
    function ()
    {
      $(this).addClass("transition");
    },
    function ()
    {
      $(this).removeClass("transition");
    }
    );

  //caption button hover
  $(".message-1.btn-hover").hover(
    function ()
    {
      $(this).append(" <span style='bold'>&rarr;</span>").css("width", "150");
    },
    function ()
    {
      $(this).css("width", "100");
      $(this).text("Sign In");
    }
    );
  $(".message-2.btn-hover").hover(
    function ()
    {
      $(this).append(" <span style='bold'>&rarr;</span>").css("width", "150");
    },
    function ()
    {
      $(this).css("width", "130");
      $(this).text("Learn more");
    }
    );
  $(".message-3.btn-hover").hover(
    function ()
    {
      $(this).append(" <span style='bold'>&rarr;</span>").css("width", "150");
    },
    function ()
    {
      $(this).css("width", "130");
      $(this).text("Learn more");
    }
    );
});

//change class when the device window width change
$(window).resize(function ()
{
  var current_width = $(window).width();

  if (current_width < 750)
  {
    $("nav#topMenu").removeClass("navbar navbar-default navbar-fixed-top").addClass("navbar navbar-inverse navbar-fixed-top");
  }
  else
  {
    $("nav#topMenu").removeClass("navbar navbar-inverse navbar-fixed-top").addClass("navbar navbar-default navbar-fixed-top");
  }
});

//change class when the scroll up or down
$(window).scroll(function ()
{
  var scroll = $(window).scrollTop() - 200;
  var current_width = $(window).width();

  if (scroll < 100 && current_width > 750)
  {
    $("nav#topMenu").removeClass("navbar navbar-inverse navbar-fixed-top").addClass("navbar navbar-default navbar-fixed-top");
  }
  else if (scroll >= 100 && current_width > 750)
  {
    $("nav#topMenu").removeClass("navbar navbar-default navbar-fixed-top").addClass("navbar navbar-inverse navbar-fixed-top");
  }

});

//define min-height of container
$(".contentContainer").css("min-height", $(window).height());

//back to top
if ($('#back-to-top').length)
{
  var scrollTrigger = 100, // px
      backToTop = function ()
      {
        var scrollTop = $(window).scrollTop();
        if (scrollTop > scrollTrigger)
        {
          $('#back-to-top').addClass('show');
        } else
        {
          $('#back-to-top').removeClass('show');
        }
      };
  backToTop();
  $(window).on('scroll', function ()
  {
    backToTop();
  });
  $('#back-to-top').on('click', function (e)
  {
    e.preventDefault();
    $('html,body').animate({
      scrollTop: 0
    }, 700);
  });
}

//stop carousel auto slide
$('.carousel').carousel({
  interval: false
});


//Google Map
function initMap()
{
  var myLatLng = { lat: 29.582550, lng: -95.098366 };
  var mapDiv = document.getElementById('map');
  var map = new google.maps.Map(mapDiv, {
    center: myLatLng,
    zoom: 19,
    scrollwheel: false
  });
}

//Show More or Less in About Us Page
function Show(id, moreText, lessText, isMore)
{
  isMore = true;

  if (isMore)
  {
    document.getElementById(id).innerHTML = moreText;
    isMore = false;
  }
  else
  {
    document.getElementById(id).innerHTML = lessText;
    isMore = true;
  }
}



