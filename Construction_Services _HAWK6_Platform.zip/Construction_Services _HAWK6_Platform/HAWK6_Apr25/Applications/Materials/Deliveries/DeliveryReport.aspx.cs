﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_Materials_Deliveries_DeliveryReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReportDocument cr = new ReportDocument();
        cr.Load(Server.MapPath("~/Applications/Materials/Deliveries/DeliveryReport.rpt"));
        CrystalReportViewer1.ReportSource = cr;
    }
}