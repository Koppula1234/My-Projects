﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_Infrastructure_SearchData : DataBaseUtility
{
  protected void Page_Load(object sender, EventArgs e)
  {
    if (!IsPostBack)
    {
      #region Bind DropDownList1 data
      try
      {
        Error.Visible = false;
        con.Open();
        cmd = new OleDbCommand("Select TableName from BasicQueries", con);
        dr = cmd.ExecuteReader();

        //add value to DropDownList 1
        DropDownList1.DataSource = dr;
        DropDownList1.DataTextField = "TableName";
        DropDownList1.DataValueField = "TableName";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, new ListItem("--Select--", "--Select--"));



      }
      catch (Exception ex)
      {
        Error.Text += " " + ex.ToString();
        Error.Visible = true;
      }
      finally
      {
        try
        {
          if (dr.HasRows)
          {
            con.Close();
          }
          else
          {
            Error.Text += " no rows";
            Error.Visible = true;
          }
        }
        catch (Exception ex)
        {
          Error.Text += " " + ex.ToString();
          Error.Visible = true;
        }
      }
      #endregion
    }
  }

  #region DropDownList1 Selected Index Changed
  protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
  {

    if (DropDownList1.SelectedValue.Equals("--Select--"))
    {
      txtentityType.Text = "";
      txtSQL_Command.Text = "";
      GridViewTable.DataSource = null;
      GridViewTable.DataBind();
      Error.Visible = false;
    }
    else
    {
      //bind data to gridview
      txtentityType.Text = DropDownList1.SelectedValue;
      txtSQL_Command.Text = String.Format("Select * from {0}", DropDownList1.SelectedValue);

      try
      {
        con.Open();
        cmd = new OleDbCommand(txtSQL_Command.Text, con);
        dr = cmd.ExecuteReader();
        GridViewTable.DataSource = dr;
        GridViewTable.DataBind();

        //Attribute to show the Plus Minus Button.
        GridViewTable.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

        int column_Num = GridViewTable.Rows[0].Cells.Count;

        if (column_Num >= 3)
        {
          for (int i = 2; i <= column_Num - 1; i++)
          {
            //Attribute to hide column in Phone.
            GridViewTable.HeaderRow.Cells[i].Attributes["data-hide"] = "phone";
          }
        }

        //Adds THEAD and TBODY to GridView.
        GridViewTable.HeaderRow.TableSection = TableRowSection.TableHeader;
      }
      catch (Exception ex)
      {
        Error.Text += " " + ex.ToString();
        Error.Visible = true;
      }
      finally
      {
        try
        {

        }
        catch (Exception ex)
        {
          Error.Text += " " + ex.ToString();
          Error.Visible = true;
        }
      }
    }

  }
  #endregion

  #region Display Button for Search Data Source
  protected void btnDisplay_Click(object sender, EventArgs e)
  {
    if (DropDownList1.SelectedValue.Equals("--Select--"))
    {
      txtentityType.Text = "";
      txtSQL_Command.Text = "";
      GridViewTable.DataSource = null;
      GridViewTable.DataBind();
      Error.Visible = false;
    }
    else
    {
      try
      {
        Error.Visible = false;
        con.Open();
        cmd = new OleDbCommand(txtSQL_Command.Text, con);
        dr = cmd.ExecuteReader();
        GridViewTable.DataSource = dr;
        GridViewTable.DataBind();

        //Attribute to show the Plus Minus Button.
        GridViewTable.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

        int column_Num = GridViewTable.Rows[0].Cells.Count;

        if (column_Num >= 3)
        {
          for (int i = 2; i <= column_Num - 1; i++)
          {
            //Attribute to hide column in Phone.
            GridViewTable.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
          }
        }

        //Adds THEAD and TBODY to GridView.
        GridViewTable.HeaderRow.TableSection = TableRowSection.TableHeader;
      }
      catch (Exception ex)
      {
        Error.Text += " " + ex.ToString();
        Error.Visible = true;
      }
      finally
      {
        try
        {
          if (dr.HasRows)
          {
            con.Close();
          }
          else
          {
            Error.Text += " no rows";
            Error.Visible = true;
          }
        }
        catch (Exception ex)
        {
          Error.Text += " " + ex.ToString();
          Error.Visible = true;
        }
      }
    }
  }
  #endregion
}