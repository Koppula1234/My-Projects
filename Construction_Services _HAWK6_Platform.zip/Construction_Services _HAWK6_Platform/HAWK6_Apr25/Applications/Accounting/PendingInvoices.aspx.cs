﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.IO;
using System.Diagnostics;

public partial class Applications_Accounting_PendingInvoices : DataBaseUtility
{
    protected void Page_Load(object sender, EventArgs e)
    {
        docGrid.DataSource = null;
        docGrid.DataBind();
        try
        {
            con.Open();

            int x = 0;
            x++;

            cmd = new OleDbCommand("select * from ReceivableDocs as r where r.doc_ref not in (select docref from collectreceivables as c where r.doc_ref=c.docref)", con);
            dr = cmd.ExecuteReader();
            docGrid.DataSource = dr;
            docGrid.DataBind();

            //Attribute to show the Plus Minus Button.
            docGrid.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            int column_Num = docGrid.Rows[0].Cells.Count;

            if (column_Num >= 3)
            {
                for (int i = 2; i <= column_Num - 1; i++)
                {
                    //Attribute to hide column in Phone.
                    docGrid.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
                }
            }

            //Adds THEAD and TBODY to GridView.
            docGrid.HeaderRow.TableSection = TableRowSection.TableHeader;
            con.Close();
        }
        catch (FileNotFoundException ex)
        {
           // Error.Visible = true;

        }
        catch (Exception ex)
        {
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }

    }
}