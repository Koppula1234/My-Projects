﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClosedXML.Excel;
using System.Data;

public partial class Utilities_ImportAndExportExcelFile : System.Web.UI.UserControl
{
  protected void Page_Load(object sender, EventArgs e)
  {

  }
  protected void import_Click(object sender, EventArgs e)
  {
    if (upload.HasFile)
    {
      try
      {
        string filename = Path.GetFileName(upload.FileName);
        upload.SaveAs(Server.MapPath("~/Docs/") + filename);
        string filePath = Server.MapPath("~/Docs/" + Path.GetFileName(upload.FileName));

        using (XLWorkbook workBook = new XLWorkbook(filePath))
        {
          IXLWorksheet workSheet = workBook.Worksheet(1);
          DataTable dt = new DataTable();
          bool firstRow = true;
          foreach (IXLRow row in workSheet.Rows())
          {
            if (firstRow)
            {
              foreach (IXLCell cell in row.Cells())
              {
                dt.Columns.Add(cell.Value.ToString());
              }
              firstRow = false;
            }
            else
            {
              dt.Rows.Add();
              int i = 0;
              foreach (IXLCell cell in row.Cells())
              {
                dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                i++;
              }
            }
            excelGrid.DataSource = dt;
            excelGrid.DataBind();

            ////Attribute to show the Plus Minus Button.
            //excelGrid.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            //int column_Num = excelGrid.Rows[0].Cells.Count;

            //if (column_Num >= 3)
            //{
            //  for (int i = 2; i <= column_Num - 1; i++)
            //  {
            //    //Attribute to hide column in Phone.
            //    excelGrid.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
            //  }
            //}

            ////Adds THEAD and TBODY to GridView.
            //excelGrid.HeaderRow.TableSection = TableRowSection.TableHeader;

          }
        }
        FileInfo info = new FileInfo(filePath);
        info.Delete();
      }
      catch (Exception ex)
      {
        string error = ex.StackTrace.ToString();
      }
    }
  }
  protected void export_Click(object sender, EventArgs e)
  {
    DataTable dt = new DataTable("Excel_Data");
    foreach (TableCell cell in excelGrid.HeaderRow.Cells)
    {
      dt.Columns.Add(cell.Text);
    }
    foreach (GridViewRow row in excelGrid.Rows)
    {
      dt.Rows.Add();
      for (int i = 0; i < row.Cells.Count; i++)
      {
        dt.Rows[dt.Rows.Count - 1][i] = row.Cells[i].Text;
      }
    }
    using (XLWorkbook wb = new XLWorkbook())
    {
      wb.Worksheets.Add(dt);
      Response.Clear();
      Response.Buffer = true;
      Response.Charset = "";
      Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      Response.AddHeader("content-disposition", "attachment;filename=TestData_Export.xlsx");
      using (MemoryStream MyMemoryStream = new MemoryStream())
      {
        wb.SaveAs(MyMemoryStream);
        MyMemoryStream.WriteTo(Response.OutputStream);
        Response.Flush();
        Response.End();
      }
    }
  }
}