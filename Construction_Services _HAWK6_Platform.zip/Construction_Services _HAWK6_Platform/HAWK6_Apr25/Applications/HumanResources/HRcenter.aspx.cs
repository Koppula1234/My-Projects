﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_HumanResources_HRcenter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void ImgBtn_HRMng_Click(object sender, ImageClickEventArgs e)
    {
        //Session["HRManager"] = "HRManager";
        //Response.Redirect("ListObject.aspx");
    }
    protected void ImgBtn_emprev_Click(object sender, ImageClickEventArgs e)
    {
        Session["EmployeeReview"] = "EmployeeReview";
        Session["JobApplicant"] = null;
        Session["HREmployee"] = null;
        
        Session["HRManager"] = null;
        Session["InterviewScores"] = null;
        Response.Redirect("ListObject.aspx");
    }
    protected void ImgBtn_HREmp_Click1(object sender, ImageClickEventArgs e)
    {
        Session["HREmployee"] = "HREmployee";
        Session["JobApplicant"] = null;

        Session["EmployeeReview"] = null;
        Session["HRManager"] = null;
        Session["InterviewScores"] = null;
        Response.Redirect("ListObject.aspx");
    }


   
}