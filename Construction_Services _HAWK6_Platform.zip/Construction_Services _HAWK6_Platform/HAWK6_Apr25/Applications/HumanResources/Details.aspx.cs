﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.IO;

public partial class Applications_HumanResources_Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    string DocNum;
    string DocType;
    string DeptID;
    string JobID;
    string jobtitle = "";
    int index1 = 0;
    int index2 = 0;
    int appn = 0;
    int x = 0;
    //String connect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source =|DataDirectory|\PACS.accdb";
    String connect = @"Provider=SQLOLEDB;Data Source=mis-sql.uhcl.edu; Initial Catalog=PACS; User ID=pacs; Password=pacs2016!!";
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (ResumeUpload.HasFile)
            {
                Stream resumeStream = ResumeUpload.PostedFile.InputStream;
                int resumeLength = ResumeUpload.PostedFile.ContentLength;
                string resumeMime = ResumeUpload.PostedFile.ContentType;
                string resumeName = Path.GetFileName(ResumeUpload.PostedFile.FileName);
                byte[] buffer = new byte[resumeLength];
                using (MemoryStream ms = new MemoryStream())
                {
                    int read;
                    while ((read = resumeStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        ms.Write(buffer, 0, read);
                    }

                }

                DocNum = (string)Session["docNum"];
                DocType = (string)Session["docType"];
                DeptID = (string)Session["DeptID"];
                JobID = (string)Session["JobID"];

                OleDbConnection con = new OleDbConnection(connect);
                string qry2 = "Select max(AppNum) from Applicants";
                OleDbCommand cmd2 = new OleDbCommand(qry2, con);


                con.Open();
                appn = Convert.ToInt32(cmd2.ExecuteScalar());
                con.Close();
                string qry = "INSERT INTO Applicants_Resumes(" +
                                "FirstName,LastName,Address,Address2,Phone,Resume_Upload," +
                                "City,State,ZipCode,Country,Email,DeptID,AppNum,JobID) " +
                                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; //14 slots

                //cmd1 = null;
                string qry3 = "select * from Applicants_Jobs where DocNum = " + DocNum + " ";
                OleDbCommand cmd3 = new OleDbCommand(qry3, con);
                con.Open();
                OleDbDataReader reader = cmd3.ExecuteReader();
                while (reader.Read())
                {
                    index1 = Convert.ToInt32(reader[2]);
                    index2 = Convert.ToInt32(reader[3]);
                    jobtitle = reader[7].ToString();


                }
                con.Close();




                //string qry1 = "INSERT INTO Applicants(" +
                //                "DocNum,DocType,Index1,Index2,AppNum,zip,Name,JobTitle," +
                //                "JobID,phone,Comments) " +
                //                "VALUES ( ?,?,?,?,?,?,?,?,?,?,?)";
                //Session["tabName"] = txtTabName.Text;
                //Session["docNum"] = txtDocNum.Text;
                //Session["docType"] = txtDocType.Text;

                appn = appn + 1;

                using (OleDbConnection conn = new OleDbConnection(connect))
                {
                    OleDbCommand cmd = new OleDbCommand(qry, conn);
                    //cmd.Parameters.AddWithValue("", Convert.ToInt32(DocNum));
                    //cmd.Parameters.AddWithValue("", Convert.ToInt32(DocType));
                    cmd.Parameters.AddWithValue("", fname.Text);
                    cmd.Parameters.AddWithValue("", lname.Text);
                    cmd.Parameters.AddWithValue("", Address.Text);
                    cmd.Parameters.AddWithValue("", Address2.Text);
                    cmd.Parameters.AddWithValue("", Phone.Text);
                    cmd.Parameters.AddWithValue("", buffer);
                    //cmd.Parameters.AddWithValue("", "File");
                    cmd.Parameters.AddWithValue("", city.Text);
                    cmd.Parameters.AddWithValue("", state.Text);
                    cmd.Parameters.AddWithValue("", zipcode.Text);
                    cmd.Parameters.AddWithValue("", county.Text);
                    cmd.Parameters.AddWithValue("", email.Text);
                    cmd.Parameters.AddWithValue("", Convert.ToInt32(DeptID));
                    cmd.Parameters.AddWithValue("", appn);
                    cmd.Parameters.AddWithValue("", Convert.ToInt32(JobID));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();


                }

                insertdata();
                resetall();
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Congratulations Your Application have been Submitted Successfully')", true);
            }
        }
        catch (Exception exp)
        {
            Console.WriteLine(exp.Message);
        }
    }

    protected void insertdata()
    {
        int docnums = Convert.ToInt32(DocNum);
        docnums = docnums + 1;
        int doctypes = Convert.ToInt32(DocType);
        // int zipcodes = Convert.ToInt32(zipcode.Text);
        // int Phones = Convert.ToInt32(Phone.Text);
        string name = lname.Text + " " + fname.Text;
        string qry1 = "INSERT INTO Applicants(DocNum,DocType,Index1,Index2,AppNum,zip,Name,JobTitle,JobID,phone,Comments) VALUES(" + docnums + ",61," + index1 + "," + index2 + "," + appn + ",775,'" + name + "','" + jobtitle + "'," + JobID + ",789,'In Process')";
        string qry2 = "INSERT INTO Applicants_InterviewScores(DocNum,DocType,Index1,Index2,AppNum,JobID,Name,JobTitle,extra1,InterviewScore,Comments) VALUES(" + docnums + ",62," + index1 + "," + index2 + "," + appn + "," + JobID + ",'" + name + "','" + jobtitle + "',0,0,'Selected')";
        using (OleDbConnection conn6 = new OleDbConnection(connect))
        {


            OleDbCommand cmd10 = new OleDbCommand(qry1, conn6);
            OleDbCommand cmd11 = new OleDbCommand(qry2, conn6);
            //// for second query
            //cmd2.Parameters.AddWithValue("", Convert.ToInt32(DocNum));
            //cmd2.Parameters.AddWithValue("", 61);
            //cmd2.Parameters.AddWithValue("", index1);
            //cmd2.Parameters.AddWithValue("", index2);
            //cmd2.Parameters.AddWithValue("", appn);
            //cmd2.Parameters.AddWithValue("", Convert.ToInt32(zipcode.Text));
            //cmd2.Parameters.AddWithValue("", "sasank");
            //cmd2.Parameters.AddWithValue("", jobtitle);
            //cmd2.Parameters.AddWithValue("", JobID);
            //cmd2.Parameters.AddWithValue("", x);
            //cmd2.Parameters.AddWithValue("", "In Process");



            conn6.Open();
            cmd10.ExecuteNonQuery();
            cmd11.ExecuteNonQuery();
            conn6.Close();
        }


    }
    public void resetall()
    {
        fname.Text = "";
        lname.Text = "";
        Address.Text = "";
        Address2.Text = "";
        Phone.Text = "";
        city.Text = "";
        state.Text = "";
        zipcode.Text = "";
        county.Text = "";
        email.Text = "";

    }

}