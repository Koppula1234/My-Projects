﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Diagnostics;
using System.IO;

public partial class Applications_HumanResources_HR_Search : DataBaseUtility
{
    protected void Page_Load(object sender, EventArgs e)
    {
   

        Error.Visible = false;

    }
    protected void search_Click(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        try
        {
            con.Open();



            cmd = new OleDbCommand("SELECT emp.DocNum,emp.DocType,FirstName,LastName,Address,Address2,City,State,Zipcode,Country,phone,phone2,email,e.Benefits_Percent,emp.Dept_ID,Role,AdmiLevel,emp.Comment FROM Employees emp left outer join EmployeeBenefits e on e.EmpID=emp.DocNum WHERE emp.DocNum LIKE '%" + search.Text + "%' OR FirstName LIKE '%" + search.Text + "%' OR LastName LIKE '%" + search.Text + "%' OR City LIKE '%" + search.Text + "%' OR State LIKE '%" + search.Text + "%' OR Zipcode LIKE '%" + search.Text + "%' OR Country LIKE '%" + search.Text + "%' OR phone LIKE '%" + search.Text + "%' OR email LIKE '%" + search.Text + "%' OR emp.Dept_ID LIKE '%" + search.Text + "%' OR Role LIKE '%" + search.Text + "%'", con);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();

            //Attribute to show the Plus Minus Button.
            GridView1.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            int column_Num = GridView1.Rows[0].Cells.Count;

            if (column_Num >= 3)
            {
                for (int i = 2; i <= column_Num - 1; i++)
                {
                    //Attribute to hide column in Phone.
                    GridView1.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
                }
            }

            //Adds THEAD and TBODY to GridView.
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            con.Close();
        }
        catch (FileNotFoundException ex)
        {
            Error.Visible = true;

        }
        catch (Exception ex)
        {
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Error.Visible = false;
        int rowIndex = GridView1.SelectedIndex;
        string empid = GridView1.SelectedRow.Cells[1].Text;
        //  string docType = GridView1.SelectedRow.Cells[2].Text;
       // string com = comment.Substring(0, 5);
        Session["eid"] = empid.ToString();
        Response.Redirect("Employee_Benefits.aspx");
       
    }
}