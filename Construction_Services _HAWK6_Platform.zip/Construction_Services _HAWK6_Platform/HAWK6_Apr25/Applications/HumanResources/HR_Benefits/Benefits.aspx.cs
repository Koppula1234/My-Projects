﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Diagnostics;
using System.IO;

public partial class Applications_HumanResources_Benefits : DataBaseUtility
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Error.Visible = false;
        GridView1.DataSource = null;
        GridView1.DataBind();
        try
        {
            con.Open();


            

            cmd = new OleDbCommand("Select DetailID,Benefits_percent,Comment FROM AddOnBenefits", con);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();

            //Attribute to show the Plus Minus Button.
            GridView1.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            int column_Num = GridView1.Rows[0].Cells.Count;

            if (column_Num >= 3)
            {
                for (int i = 2; i <= column_Num - 1; i++)
                {
                    //Attribute to hide column in Phone.
                    GridView1.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
                }
            }

            //Adds THEAD and TBODY to GridView.
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            con.Close();
        }
        catch (FileNotFoundException ex)
        {
            Error.Visible = true;

        }
        catch (Exception ex)
        {
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Error.Visible = false;
        int rowIndex = GridView1.SelectedIndex;
        string comment = GridView1.SelectedRow.Cells[3].Text;
      //  string docType = GridView1.SelectedRow.Cells[2].Text;
        string com = comment.Substring(0, 5);
        Session["c"]  = com.ToString();
        Response.Redirect("Benefit_Detail.aspx");
       
    }
    public int RowIndex { get; set; }
}