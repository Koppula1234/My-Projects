﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Diagnostics;
using System.IO;

public partial class Applications_HumanResources_Benefit_Detail : DataBaseUtility
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Error.Visible = false;
        GridView1.DataSource = null;
        GridView1.DataBind();
        string comment = Session["c"].ToString();
        try
        {
            con.Open();



            cmd = new OleDbCommand("Select * FROM EmployeeBenefits_Details WHERE Comment LIKE '%" + comment.ToString() + "%'", con);
            dr = cmd.ExecuteReader();
            
            GridView1.DataSource = dr;
            GridView1.DataBind();
           

            //Attribute to show the Plus Minus Button.
            GridView1.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            int column_Num = GridView1.Rows[0].Cells.Count;

            if (column_Num >= 3)
            {
                for (int i = 2; i <= column_Num - 1; i++)
                {
                    //Attribute to hide column in Phone.
                    GridView1.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
                }
            }

            //Adds THEAD and TBODY to GridView.
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            con.Close();
        }
        catch (FileNotFoundException ex)
        {
            Error.Visible = true;

        }
        catch (Exception ex)
        {
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }

    }
    protected void ChangePercentage_Click(object sender, EventArgs e)
    {
        string comment = Session["c"].ToString();
        OleDbCommand cmd1 = new OleDbCommand("update EmployeeBenefits_Details set Benefits_percent="+ Convert.ToInt32(txtPercentage.Text) +" where Comment LIKE '%" + comment.ToString() + "%'",con);
        OleDbCommand cmd2 = new OleDbCommand("update AddOnBenefits set Benefits_percent=" + Convert.ToInt32(txtPercentage.Text) + " where Comment LIKE '%" + comment.ToString() + "%'", con);
        OleDbCommand cmd3 = new OleDbCommand("update EmployeeBenefits set Benefits_Percent=t.sbp from (select DocNum, sum(Benefits_percent) as sbp from EmployeeBenefits_Details group by DocNum) t where EmployeeBenefits.DocNum=t.DocNum", con);
        con.Open();
        
        cmd1.ExecuteNonQuery();
        cmd2.ExecuteNonQuery();
        cmd3.ExecuteNonQuery();
        con.Close();
     


    }
}