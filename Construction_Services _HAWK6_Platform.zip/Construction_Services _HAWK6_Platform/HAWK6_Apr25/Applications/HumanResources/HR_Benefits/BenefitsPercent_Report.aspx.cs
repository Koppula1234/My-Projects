﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_HumanResources_HR_Benefits_BenefitsPercent_Report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReportDocument cr = new ReportDocument();
        cr.Load(Server.MapPath("~/Applications/HumanResources/HR_Benefits/CrystalReport_Benefit_Percents.rpt"));
        CrystalReportViewer1.ReportSource = cr;

    }
}