﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_HumanResources_Employee_Benefits : DataBaseUtility
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Error.Visible = false;
        GridView1.DataSource = null;
        GridView1.DataBind();
        int empid =Convert.ToInt32(Session["eid"].ToString());
        if (!Page.IsPostBack)
        {
            try
            {
                Error.Visible = false;
                con.Open();
                cmd = new OleDbCommand("select comment,DetailID from AddOnBenefits as a where a.DetailID not in(select DetailID from EmployeeBenefits_Details where EmpID="+ empid +")", con);
              // OleDbCommand cmd2 = new OleDbCommand("select * from EmployeeBenefits_Details where EmpID="+ empid +"", con);
                
                dr = cmd.ExecuteReader();

                dropDownBenefits.DataSource = dr;
                dropDownBenefits.DataTextField = "comment";
                dropDownBenefits.DataValueField = "DetailID";
                dropDownBenefits.DataBind();
                dropDownBenefits.Items.Insert(0, new ListItem("--Select--", "--Select--"));
                

            }
            catch (Exception ex)
            {
                Error.Visible = true;
                Debug.WriteLine("********************************************************************");
                Debug.WriteLine("Exception Caught: {0}", ex.Message);
                Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                Debug.WriteLine("********************************************************************");
            }
            finally
            {
                try
                {
                    if (dr.HasRows)
                    {
                        con.Close();
                        Error.Visible = false;
                    }
                    else
                    {
                        Error.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    Error.Visible = true;
                    Debug.WriteLine("********************************************************************");
                    Debug.WriteLine("Exception Caught: {0}", ex.Message);
                    Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                    Debug.WriteLine("********************************************************************");
                }

            }
        
        try
            {
                Error.Visible = false;
                con.Open();
                cmd = new OleDbCommand("select comment,DetailID from AddOnBenefits as a where a.DetailID in(select DetailID from EmployeeBenefits_Details where EmpID="+ empid +")", con);
              // OleDbCommand cmd2 = new OleDbCommand("select * from EmployeeBenefits_Details where EmpID="+ empid +"", con);
                
                dr = cmd.ExecuteReader();

                DropDowndelben.DataSource = dr;
                DropDowndelben.DataTextField = "comment";
                DropDowndelben.DataValueField = "DetailID";
                DropDowndelben.DataBind();
                DropDowndelben.Items.Insert(0, new ListItem("--Select--", "--Select--"));
                

            }
            catch (Exception ex)
            {
                Error.Visible = true;
                Debug.WriteLine("********************************************************************");
                Debug.WriteLine("Exception Caught: {0}", ex.Message);
                Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                Debug.WriteLine("********************************************************************");
            }
            finally
            {
                try
                {
                    if (dr.HasRows)
                    {
                        con.Close();
                        Error.Visible = false;
                    }
                    else
                    {
                        Error.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    Error.Visible = true;
                    Debug.WriteLine("********************************************************************");
                    Debug.WriteLine("Exception Caught: {0}", ex.Message);
                    Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                    Debug.WriteLine("********************************************************************");
                }

            }
        }
        try
        {
            con.Open();



            cmd = new OleDbCommand("Select * FROM EmployeeBenefits_Details WHERE EmpID ="+ empid +"", con);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            //while(dr.HasRows)
            //{
            //    Session["DocNum"] = dr[0].ToString();
            //    Session["ProcID"] = dr[4].ToString();
            //    Session["quant"] = dr[5].ToString();
            //}
            
            
            

            //Attribute to show the Plus Minus Button.
            GridView1.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

            int column_Num = GridView1.Rows[0].Cells.Count;

            if (column_Num >= 3)
            {
                for (int i = 2; i <= column_Num - 1; i++)
                {
                    //Attribute to hide column in Phone.
                    GridView1.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
                }
            }

            //Adds THEAD and TBODY to GridView.
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            con.Close();
        }
        catch (FileNotFoundException ex)
        {
            Error.Visible = true;

        }
        catch (Exception ex)
        {
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }

    }
    protected void AddBenefit_Click(object sender, EventArgs e)
    {
        string DNum=GridView1.Rows[0].Cells[0].Text;
        int DocNum = Convert.ToInt32(DNum);
        string pid = GridView1.Rows[0].Cells[4].Text;
        int procid = Convert.ToInt32(pid);
        string quan = GridView1.Rows[0].Cells[5].Text;
        int quant = Convert.ToInt32(quan);
        //int DocNum = Convert.ToInt32(Session["DocNum"].ToString());
        //int procid = Convert.ToInt32(Session["ProcID"].ToString());
        //int quant = Convert.ToInt32(Session["quant"].ToString());
        int empid = Convert.ToInt32(Session["eid"].ToString());
        int detailid = Convert.ToInt32(dropDownBenefits.SelectedValue);
        int perc = Convert.ToInt32(percent.Value);
        //int percent = Convert.ToInt32(Session["Benefits_percent"].ToString());
        OleDbCommand cmd1 = new OleDbCommand("insert into EmployeeBenefits_Details values(" + DocNum + ",62," + detailid + "," + empid + "," + procid + "," + quant + "," + perc + ",'" + dropDownBenefits.SelectedItem.ToString() + "')", con);
        OleDbCommand cmd3 = new OleDbCommand("update EmployeeBenefits set Benefits_Percent=t.sbp from (select DocNum, sum(Benefits_percent) as sbp from EmployeeBenefits_Details group by DocNum) t where EmployeeBenefits.DocNum=t.DocNum", con);
        con.Open();

        cmd1.ExecuteNonQuery();
        cmd3.ExecuteNonQuery();
        con.Close();

    }
    protected void dropDownBenefits_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int detailid = Convert.ToInt32(dropDownBenefits.SelectedValue);
            con.Open();
            cmd = new OleDbCommand("select Benefits_percent from AddOnBenefits where DetailID=" + detailid + "", con);
            // OleDbCommand cmd2 = new OleDbCommand("select * from EmployeeBenefits_Details where EmpID="+ empid +"", con);

            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int x = Convert.ToInt32(dr[0].ToString());
               // percent = x;
                percent.Value = x.ToString();
            }
        }
        catch (Exception ex)
        {
            Error.Visible = true;
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }
        finally
        {
            try
            {
                if (dr.HasRows)
                {
                    con.Close();
                    Error.Visible = false;
                }
                else
                {
                    Error.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Error.Visible = true;
                Debug.WriteLine("********************************************************************");
                Debug.WriteLine("Exception Caught: {0}", ex.Message);
                Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                Debug.WriteLine("********************************************************************");
            }

        }
    }
    protected void deletebenefits_Click(object sender, EventArgs e)
    {
        string DNum = GridView1.Rows[0].Cells[0].Text;
        int DocNum = Convert.ToInt32(DNum);
        string pid = GridView1.Rows[0].Cells[4].Text;
        int procid = Convert.ToInt32(pid);
        string quan = GridView1.Rows[0].Cells[5].Text;
        int quant = Convert.ToInt32(quan);
        //int DocNum = Convert.ToInt32(Session["DocNum"].ToString());
        //int procid = Convert.ToInt32(Session["ProcID"].ToString());
        //int quant = Convert.ToInt32(Session["quant"].ToString());
        int empid = Convert.ToInt32(Session["eid"].ToString());
        int detailid = Convert.ToInt32(DropDowndelben.SelectedValue);
        int perc = Convert.ToInt32(percentdel.Value);
        //int percent = Convert.ToInt32(Session["Benefits_percent"].ToString());
        OleDbCommand cmd1 = new OleDbCommand("delete from EmployeeBenefits_Details where DocNum=" + DocNum + " and DetailID=" + detailid + "", con);
        OleDbCommand cmd3 = new OleDbCommand("update EmployeeBenefits set Benefits_Percent=t.sbp from (select DocNum, sum(Benefits_percent) as sbp from EmployeeBenefits_Details group by DocNum) t where EmployeeBenefits.DocNum=t.DocNum", con);
        con.Open();

        cmd1.ExecuteNonQuery();
        cmd3.ExecuteNonQuery();
        con.Close();
    }
    protected void DropDowndelben_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int detailid = Convert.ToInt32(DropDowndelben.SelectedValue);
            con.Open();
            cmd = new OleDbCommand("select Benefits_percent from AddOnBenefits where DetailID=" + detailid + "", con);
            // OleDbCommand cmd2 = new OleDbCommand("select * from EmployeeBenefits_Details where EmpID="+ empid +"", con);

            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int x = Convert.ToInt32(dr[0].ToString());
                // percent = x;
                percentdel.Value = x.ToString();
            }
        }
        catch (Exception ex)
        {
            Error.Visible = true;
            Debug.WriteLine("********************************************************************");
            Debug.WriteLine("Exception Caught: {0}", ex.Message);
            Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
            Debug.WriteLine("********************************************************************");
        }
        finally
        {
            try
            {
                if (dr.HasRows)
                {
                    con.Close();
                    Error.Visible = false;
                }
                else
                {
                    Error.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Error.Visible = true;
                Debug.WriteLine("********************************************************************");
                Debug.WriteLine("Exception Caught: {0}", ex.Message);
                Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
                Debug.WriteLine("********************************************************************");
            }

        }
    }
}