﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

public partial class Utilities_ChangeDocument : DataBaseUtility
{
  DataTable _detailTable;
  List<String> _detailList;
  DataTable dt = new DataTable();
  int dtRow = 0;
  IdentityObject _ident; 
    double discount = 0;
  
  protected void Page_Load(object sender, EventArgs e)
  {
    Error.Visible = false;

     _ident = (IdentityObject)Session["ident"];
    string tableName = (string)(Session["tableName"]);
    string docType = (string)(Session["docType"]);
    string docNum = (string)(Session["docNum"]);

    txtTableName.Text = tableName;
    txtDocType.Text = docType;
    txtDocNum.Text = docNum;
    ResetCommand();
    populateMaterials();

      if(!IsPostBack)
      {
          Session["dataRows"] = 0;
      }
  }

  protected void Button_Validate_Click(object sender, EventArgs e)
  {
    try
    {
      Error.Visible = false;
      _detailList = (List<string>)Session["detailList"];
      StringBuilder dataString1 = new StringBuilder();
      dataString1.Append(txtDocNum.Text.Trim() + ", ");
      dataString1.Append(txtDocType.Text.Trim() + ", ");
      dataString1.Append(txtExtRef.Text.Trim() + ", ");
      dataString1.Append(txtIntRef.Text.Trim() + ", ");
      dataString1.Append(txtStatus.Text.Trim() + ", ");
      dataString1.Append(txtProcNum.Text.Trim() + ", ");
      dataString1.Append("'" + txtValue.Text.Trim() + "', ");
      dataString1.Append("'" + txtValue2.Text.Trim() + "', ");
      dataString1.Append(txtNumValue1.Text.Trim() + ", ");
      dataString1.Append(txtNumValue2.Text.Trim() + ", ");
      dataString1.Append("'" + txtComments.Text.Trim() + "'");
      // datastrings.Add(dataString1.ToString());
      TextBox_Details.Text = dataString1.ToString();
      _detailTable = (DataTable)Session["dataTable"];
      int lastrow = _detailTable.Rows.Count - 1;
      for (int i = 0; i <= lastrow; i++)
      {
        TextBox_Details.Text += "\r\n";
        for (int j = 0; j < 7; j++)
          TextBox_Details.Text += _detailTable.Rows[i][j].ToString().Trim() + ", ";
        TextBox_Details.Text += "'" + _detailTable.Rows[i][7].ToString().Trim() + "'";
      }
    }
    catch (Exception ex)
    {
      Error.Visible = true;
      Debug.WriteLine("********************************************************************");
      Debug.WriteLine("Exception Caught: {0}", ex.Message);
      Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
      Debug.WriteLine("********************************************************************");
    }
  }


  protected void button_GetDoc_Click(object sender, EventArgs e)
  {
    // txtQuery.Text = "select * from " + txtTableName.Text + " where docNum = " + Convert.ToInt32(txtDocNum.Text) + "And docType = " + Convert.ToInt32(txtDocType.Text);
    try
    {
      Error.Visible = false;
      Console.WriteLine(txtQuery.Text);
      List<string> _selDocStr = DataBaseUtility.GetList(txtQuery.Text);

      string[] selDocStr = _selDocStr[1].Split(',');
      txtExtRef.Text = selDocStr[2];
      txtIntRef.Text = selDocStr[3];
      txtProcNum.Text = selDocStr[4];
      txtStatus.Text = selDocStr[5];
      txtValue.Text = selDocStr[6];
      txtValue2.Text = selDocStr[7];
      txtNumValue1.Text = selDocStr[8];
      txtNumValue2.Text = selDocStr[9];
      txtComments.Text = selDocStr[10];
      string cmdStr2 = String.Format("select * from {0}_Details where docNum = {1} and doctype = {2}",
                txtTableName.Text.Trim(), txtDocNum.Text, txtDocType.Text);

      _detailTable = DataBaseUtility.GetTable(cmdStr2);
      dataGridItems.DataSource = _detailTable;
      dataGridItems.DataBind();

      //Attribute to show the Plus Minus Button.
      dataGridItems.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

      int column_Num = dataGridItems.Rows[0].Cells.Count;

      if (column_Num >= 3)
      {
        for (int i = 2; i <= column_Num - 1; i++)
        {
          //Attribute to hide column in Phone.
            dataGridItems.HeaderRow.Cells[i].Attributes["data-hide"] = "phone,tablet";
        }
      }

      //Adds THEAD and TBODY to GridView.
      dataGridItems.HeaderRow.TableSection = TableRowSection.TableHeader;

      //  _detailList = DataBaseUtility.GetList(cmdStr2);
      Session["detailTable"] = _detailTable;

    }
    catch (Exception ex)
    {
      Error.Visible = true;
      Debug.WriteLine("********************************************************************");
      Debug.WriteLine("Exception Caught: {0}", ex.Message);
      Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
      Debug.WriteLine("********************************************************************");

    }

  }
  protected void Button_Delete_Click(object sender, EventArgs e)
  {
    try
    {
      Error.Visible = false;
      ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert (Deleting the Document will erase all the existing data permenanatly. Are you sure you want to DELETE the Document ?", true);
      DataBaseUtility.DeleteDocument(base.ident, txtTableName.Text, txtDocNum.Text, txtDocType.Text);

    }
    catch (Exception ex)
    {
      Error.Visible = true;
      Debug.WriteLine("********************************************************************");
      Debug.WriteLine("Exception Caught: {0}", ex.Message);
      Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
      Debug.WriteLine("********************************************************************");
    }
  }

  //protected void Button_Save_Click(object sender, EventArgs e)
  //{
  //  try
  //  {
  //    Error.Visible = false;
  //    GenDoc myDoc = new GenDoc();
  //    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "Alert! Are you sure that you want to Save the changes? ", true);
  //    // if (response == "no") return; else 
  //    //  return; 
  //    string _tableName = Session["tableName"].ToString();
  //    List<string> myData = new List<string>();
  //    string[] records = TextBox_Details.Text.Split('\r');
  //    for (int i = 0; i < records.Length; i++)
  //      myData.Add(records[i].ToString().Trim());
  //    // int myDataCount = myData.Count;
  //    myDoc = new GenDoc(myData);
  //    int retcode = myDoc.SaveDocument(base.ident, _tableName, txtDocNum.Text, txtDocType.Text, myData);
  //    // string retMessage = myDoc.SaveDocument(base.ident, textBox_TableName.Text, textBox_DocumentID.Text, textBox_DocType.Text, myData);
  //  }

  //  catch (Exception ex)
  //  {
  //    Error.Visible = true;
  //    Debug.WriteLine("********************************************************************");
  //    Debug.WriteLine("Exception Caught: {0}", ex.Message);
  //    Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
  //    Debug.WriteLine("********************************************************************");
  //  }
  //}

  protected void Button_Save_Click(object sender, EventArgs e)
  {
      try
      {
          Error.Visible = false;
          GenDoc myDoc = new GenDoc();
          ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Are you sure that you want to save ? ')", true);
          // if (response == "no") return; else 
          //  return; 
          string _tableName = Session["tableName"].ToString();
          List<string> myData = new List<string>();
          string[] records = TextBox_Details.Text.Split('\r');
          for (int i = 0; i < records.Length; i++)
              myData.Add(records[i].ToString().Trim());
          int myDataCount = myData.Count;
          myDoc = new GenDoc(myData);
          int retcode = myDoc.SaveDocument(base.ident, _tableName, txtDocNum.Text, txtDocType.Text, myData);
          //IdentityObject iden = (IdentityObject)Session["ident"];


          int rowNum = DataBaseUtility.GetNextNumber("ProcessDocs", 0, 0, 0);
          
          retcode = myDoc.SaveDocument(base.ident, "ProcessDocs", txtDocNum.Text, txtDocType.Text, myData);

          
          string docsQuery = String.Format("Update ProcessDocs SET DocNum = {0}, DocRef = {0} WHERE DocNum = {1}", rowNum, txtDocNum.Text);
          DataBaseUtility.Execute(ident, docsQuery);

         
          string docsDetailsquery = String.Format("Update ProcessDocs_Details SET DocNum = {0} WHERE DocNum = {1}", rowNum, txtDocNum.Text);
          for (int i = 1; i < myData.Count;i++ )
          {
              DataBaseUtility.Execute(ident, docsDetailsquery); ;
          }                        

      }

      catch (Exception ex)
      {
          Error.Visible = true;
          Debug.WriteLine("********************************************************************");
          Debug.WriteLine("Exception Caught: {0}", ex.Message);
          Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
          Debug.WriteLine("********************************************************************");
      }
  }

  protected virtual void ResetCommand()
  {
    try
    {
      Error.Visible = false;
      //txtTableName.Text =  (string)(Session["TableName"]);
      //txtDocType.Text = (string)(Session["docType"]);
      //txtDocNum.Text = (string)(Session["docNum"]);
      Session["tableName"] = txtTableName.Text;
      Session["docNum"] = txtDocNum.Text;
      Session["docType"] = txtDocType.Text;
      string part1 = "select * from " + txtTableName.Text;
      string part2 = "";
      string part3 = "";
      if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
        part2 = " where docType = " + txtDocType.Text;
      if ((txtDocNum.Text != "") && (txtDocNum.Text != "0"))
        if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
          part3 = " and DocNum =  " + txtDocNum.Text; // comboBox_DocNum.SelectedItem.ToString();
        else part3 = " where DocNum =  " + txtDocNum.Text; //comboBox_DocNum.SelectedItem.ToString();

      txtQuery.Text = part1 + part2 + part3;
      Session["query"] = txtQuery.Text;
    }
    catch (Exception ex)
    {
      Error.Visible = true;
      Debug.WriteLine("********************************************************************");
      Debug.WriteLine("Exception Caught: {0}", ex.Message);
      Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
      Debug.WriteLine("********************************************************************");
    }
  }

  //protected virtual void ResetCommand()
  //{
  //    string part1 = "select * from " + txtTableName.Text;
  //    string part2 = "";
  //    string part3 = "";
  //    if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
  //        part2 = " where docType = " + txtDocType.Text;
  //    if ((txtDocNum.Text != "") && (txtDocNum.Text != "0"))
  //        if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
  //            part3 = " and DocNum =  " + txtDocNum.Text; // comboBox_DocNum.SelectedItem.ToString();
  //        else part3 = " where DocNum =  " + txtDocNum.Text; //comboBox_DocNum.SelectedItem.ToString();

  //    txtQuery.Text = part1 + part2 + part3;
  //}

  protected void Button_Reset_Click(object sender, EventArgs e)
  {
    try
    {
      Error.Visible = false;
      //txtTableName.Text = Session["tableName"] as String ;
      //txtDocNum.Text = Session["docNum"] as String ;
      //txtDocType.Text = Session["docType"] as String ;
      string part1 = "select * from " + txtTableName.Text;
      string part2 = "";
      string part3 = "";
      if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
        part2 = " where docType = " + txtDocType.Text;
      if ((txtDocNum.Text != "") && (txtDocNum.Text != "0"))
      {
        if ((txtDocType.Text != "") && (txtDocType.Text != "0"))
          part3 = " and DocNum =  " + txtDocNum.Text; // comboBox_DocNum.SelectedItem.ToString();
        else part3 = " where DocNum =  " + txtDocNum.Text; //comboBox_DocNum.SelectedItem.ToString();
      }
      txtQuery.Text = part1 + part2 + part3;
      Session["tableName"] = txtTableName.Text;
      Session["docNum"] = txtDocNum.Text;
      Session["docType"] = txtDocType.Text;
      Session["query"] = txtQuery.Text;
    }
    catch (Exception ex)
    {
      Error.Visible = true;
      Debug.WriteLine("********************************************************************");
      Debug.WriteLine("Exception Caught: {0}", ex.Message);
      Debug.WriteLine("Exception Caught: {0}", ex.StackTrace);
      Debug.WriteLine("********************************************************************");
    }

  }

  protected void txtDocNum_TextChanged(object sender, EventArgs e)
  {
    //    Session["docNum"] = txtDocNum.Text;
    //    txtDocNum.Text = (String) Session["docNum"];

  }
  protected void txtTableName_TextChanged(object sender, EventArgs e)
  {
    //    Session["TableName"] = txtTableName.Text;
    //    txtTableName.Text = (String)Session["TableName"];

  }
  protected void txtDocType_TextChanged(object sender, EventArgs e)
  {
    //Session["docType"] = txtDocType.Text;
    //txtDocType.Text = (String)Session["docType"];

  }
  protected void GoBack_Click(object sender, EventArgs e)
  {
    Response.Redirect("DisplaySelectedObject.aspx");
  }


  private void populateMaterials()
  {
      string query = String.Format("Select DocNum, MaterialName From Materials");

      List<string> materialsList = GetList(query);

      foreach (var value in materialsList)
      {
          dropDownMaterialsList.Items.Add(value);
      }
  }

  private void populateFormValues()
  {

      txtTableName.Text = "SalesOfMaterials";
      txtDocNum.Text = Convert.ToString(GetNextNumber("SalesOfMaterials", 0, 0, 0) - 1);
      txtDocType.Text = "21";
      Session["tableName"] = txtTableName.Text;
      Session["docNum"] = txtDocNum.Text;
      Session["docType"] = txtDocType.Text;
      txtProcNum.Text = Convert.ToString(GetNextNumber("SalesOfMaterials", 3, 0, 0) - 1);
     

      string cmdStr = String.Format("select * from {0} where docNum = {1} and DocType = {2}",      "Materials", txtDocNum.Text, txtDocType.Text);

      txtQuery.Text = cmdStr;



  }
  protected void dropDownMaterialsList_SelectedIndexChanged(object sender, EventArgs e)
  {
      populateFormValues();

      string query = String.Format("Select [Price] from [Materials] where [DocNum] = {0}", dropDownMaterialsList.SelectedItem.ToString().Substring(0, 3));
   
      List<string> priceList = GetList(query);
      string unitPrice = null;
      foreach (var value in priceList)
      {
          unitPrice = value.ToString();
      }
      txtNumValue2.Text = unitPrice;

  }
  protected void btnAddItem_Click(object sender, EventArgs e)
  {
      populateFormValues();
      if (Convert.ToInt32(Session["dataRows"]) == 0)
      {
          
          txtNumValue1.Text = "0";
          dt.Columns.Add("DocNum", typeof(Int32));
          dt.Columns.Add("DocType", typeof(Int32));
          dt.Columns.Add("SalesOrder_ID", typeof(Int32));
          dt.Columns.Add("Product_ID", typeof(Int32));
          dt.Columns.Add("Process_ID", typeof(Int32));
          dt.Columns.Add("Quantity", typeof(double));
          dt.Columns.Add("Unit_Price", typeof(double));
          dt.Columns.Add("Comments", typeof(string));
      }

      else
      {
          dt = (DataTable)Session["dataTable"];
      }
      txtNumValue3.Text = (Convert.ToDouble(txtNumValue1.Text) + Convert.ToDouble(txtNumValue2.Text) * Convert.ToInt16(txtQuantity.Text)).ToString();//actual price

      txtNumValue1.Text = (Convert.ToDouble(txtNumValue1.Text) + Convert.ToDouble(txtNumValue2.Text) * Convert.ToInt16(txtQuantity.Text)).ToString();
      dt.Rows.Add(Session["docNum"].ToString().Trim(), Session["docType"].ToString().Trim(), txtProcNum.Text, dropDownMaterialsList.SelectedItem.ToString().Substring(0, 3), GetNextNumber("SalesOfMaterials_Details", 4, 0, 0) - 1, txtQuantity.Text, txtNumValue2.Text, txtComments.Text);          

      Session["dataTable"] = dt;
      dataGridItems.DataSource = dt;
      dataGridItems.DataBind();
      ++dtRow;
      Session["dataRows"] = dtRow;      
          
  }
  

    public void ApplyDiscount() 
  {
        
        double totalPrice = Convert.ToDouble(txtNumValue1.Text);

        if(totalPrice>=100)

        {
            discount = .20;
        }

        else if(totalPrice >= 50)
        {
            discount = .15;
        }
        else if(totalPrice>=25)
        {
            discount = .05;
        }

        if(discount != 0)
        {
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Discount Applied to your order ! ')", true);
        }
  }

  protected void button_discount_Click(object sender, EventArgs e)

  {
      ApplyDiscount();
      txtNumValue1.Text = (Convert.ToDouble(txtNumValue1.Text) - (Convert.ToDouble(txtNumValue1.Text) * discount)).ToString();

  }
}