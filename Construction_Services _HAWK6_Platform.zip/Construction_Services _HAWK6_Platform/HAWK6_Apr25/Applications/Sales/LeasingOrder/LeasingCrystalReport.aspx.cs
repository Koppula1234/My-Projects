﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;

public partial class Applications_Sales_LeasingOrder_LeasingCrystalReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReportDocument cr = new ReportDocument();
        cr.Load(Server.MapPath("~/Applications/Sales/LeasingOrder/CrystalReport1.rpt"));
        CrystalReportViewer1.ReportSource = cr;
    }
}