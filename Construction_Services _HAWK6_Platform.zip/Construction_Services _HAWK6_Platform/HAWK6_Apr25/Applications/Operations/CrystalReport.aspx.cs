﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;

public partial class Applications_Operations_CrystalReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
  

        ReportDocument cr = new ReportDocument();
        cr.Load(Server.MapPath("~/Applications/Operations/CrystalReport_Operations.rpt"));
        CrystalReportViewer1.ReportSource = cr;

    

}
}