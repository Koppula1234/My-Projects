﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_Payroll_CrystalReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //applications
        //Accounting.CrystalReport_Accounting rpt = new Accounting.CrystalReport_Accounting();
        //CrystalReport_Viewer cr = new CrystalReport_Viewer();
        //cr.crystalReportViewer1.ReportSource = rpt;
        //cr.Show();




        ReportDocument cr = new ReportDocument();
        cr.Load(Server.MapPath("~/Applications/Payroll/CrystalReport2.rpt"));
        CrystalReportViewer1.ReportSource = cr;
        

    }
}