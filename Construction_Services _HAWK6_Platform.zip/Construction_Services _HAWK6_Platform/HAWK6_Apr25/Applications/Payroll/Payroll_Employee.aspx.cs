﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using System.Net.Mail;
using System.Net;
using System.Web.UI.DataVisualization.Charting;

public partial class Applications_Payroll_Payroll_Employee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void ImageButtonViewTimeCard_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "TimeCards");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);
    }
    protected void ImageButtonViewGrossPay_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "GrossPay");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);
    }
    protected void ImageButtonViewNetPay_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "NetPay");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);
    }
    protected void ImageButtonCharts_Click(object sender, ImageClickEventArgs e)
    {
        IdentityObject ident = (IdentityObject)Session["ident"];

        if (ident.Role.Trim().Equals("Manager"))
        {
            Response.Redirect("~/Applications/Payroll/ChartsManager.aspx");
        }
        else
        {
            Response.Redirect("~/Applications/Payroll/ChartsEmployee.aspx");
        }
    }
    protected void ImageButtonPaySlip_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Applications/Payroll/Payslip.aspx");
    }
    protected void ImageButtonExportExcel_Click(object sender, ImageClickEventArgs e)
    {
        IdentityObject ident = (IdentityObject)Session["ident"];
        string query = "select * from TimeCards_Details where EmpID = " + ident.UserID + ";";
        DataTable dtExcel = DataBaseUtility.GetTable(query);

        Excel.Application xlApp;
        Excel.Workbook xlWorkBook;
        Excel.Worksheet xlWorkSheet;

        object misValue = System.Reflection.Missing.Value;
        xlApp = new Excel.Application();
        xlWorkBook = xlApp.Workbooks.Add(misValue);
        
        var xlSheets = xlWorkBook.Sheets as Excel.Sheets;
        var xlNewSheet = (Excel.Worksheet)xlSheets.Add(xlSheets[1], Type.Missing, Type.Missing, Type.Missing);
        xlWorkSheet = xlNewSheet;
        xlWorkSheet= (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        
        xlWorkSheet.Name = "TimeCard Details";
        int row = 1, col = 1;

        if(row==1)
        {
            xlWorkSheet.Cells[row,1] = "Doc Num";
            xlWorkSheet.Cells[row,2] = "Doc Type";
            xlWorkSheet.Cells[row,3] = "Emp ID";
            xlWorkSheet.Cells[row,4] = "Day of Week";
            xlWorkSheet.Cells[row,5] = "Number of Hours";
            xlWorkSheet.Cells[row,6] = "Index1";
            xlWorkSheet.Cells[row,7] = "Index2";
            xlWorkSheet.Cells[row,8] = "Comments";

            row++;
        }

        for (int i = 0; i < dtExcel.Rows.Count; i++)
        {
            col = 1;
            for (int j = 0; j < dtExcel.Columns.Count; j++)
            {
                xlWorkSheet.Cells[row,col] = dtExcel.Rows[i].ItemArray[j].ToString();
                col++;
            }
            row++;
        }

        xlWorkBook.SaveAs("Payroll_Employee.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
        xlWorkBook.Close(true, misValue, misValue);
        xlApp.Quit();

        releaseObject(xlWorkSheet);
        releaseObject(xlWorkBook);
        releaseObject(xlApp);
        Response.Write("<script type=\"text/javascript\">alert('Excel file created. Excel file is Saved in Documents folder.');</script>");

    }
    private void releaseObject(object obj)
    {
        try
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
        }
        catch (Exception ex)
        {
            obj = null;
            //MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
        }
        finally
        {
            GC.Collect();
        }
    }
    protected void ImageButtonSendEmail_Click(object sender, ImageClickEventArgs e)
    {
        try
         {
            MailMessage mM = new MailMessage();
            mM.From = new MailAddress("v.shashidhar2212@hotmail.com");
            mM.To.Add("rolandbaker101@hotmail.com");
            mM.Subject = " sad testing";
            mM.Attachments.Add(new Attachment(@"C:\Users\shashidhar v\Documents\Payroll_Employee.xls"));
            mM.Body = "attachment";
            mM.IsBodyHtml = true;
            SmtpClient sC = new SmtpClient("smtp.live.com");
            sC.Port = 25;
            sC.Credentials = new NetworkCredential("v.shashidhar2212@hotmail.com", "sad@password");
            sC.EnableSsl = true;
            sC.Send(mM);
        }
        catch (Exception ex)
        {
            Response.Write("mailbox unavailable. the server response was 5.7.1 unable to relay for email address");
        }
    }
}