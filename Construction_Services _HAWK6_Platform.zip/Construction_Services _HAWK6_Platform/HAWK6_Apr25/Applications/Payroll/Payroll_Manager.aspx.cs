﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Net.Mail;
using System.Net;

public partial class Applications_Payroll_Payroll_Manager : System.Web.UI.Page
{
    IdentityObject ident = ASP.global_asax.Global.io;

    protected void Page_Load(object sender, EventArgs e)
    {
        HttpContext.Current.Session["tablename"] = " ";
    }

    protected void ImageButtonCrystalreport_Click(object sender, ImageClickEventArgs e)
    {                 
        string url = "~/Applications/Payroll/CrystalReport.aspx";
        Response.Redirect(url);
    }

    protected void ImageButtonCalGrossPay_Click(object sender, ImageClickEventArgs e)
    {
        getTimeCardDetails();
        calDeductionsDetails();
        calDeductions();
        Response.Write("<script type=\"text/javascript\">alert('Gross Pay has been calculated successfully');</script>");
    }
    protected void ImageButtonCalNetPay_Click(object sender, ImageClickEventArgs e)
    {
        calNetPay();
        Response.Write("<script type=\"text/javascript\">alert('Net Pay has been calculated successfully');</script>");
    }

    protected void ImageButtonTimeCard_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "TimeCards");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);

    }
    protected void ImageButtonViewGrossPay_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "GrossPay");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);
    }
    protected void ImageButtonViewNetPay_Click(object sender, ImageClickEventArgs e)
    {
        var nameValues = HttpUtility.ParseQueryString(Request.QueryString.ToString());
        nameValues.Set("TableName", "NetPay");
        string url = "~/Applications/Payroll/ListObject.aspx";
        string updatedQueryString = "?" + nameValues.ToString();
        Response.Redirect(url + updatedQueryString);
    }

    //Methods used for gross and net pay calculations

    public void getTimeCardDetails()
    {
        string query = String.Format("select * from {0} order by DocNum", "TimeCards");
        DataTable dt = DataBaseUtility.GetTable(query);

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            int emp_id = Convert.ToInt16(dt.Rows[i]["EmpID"].ToString());
            int regHours = Convert.ToInt16(dt.Rows[i]["RegularHours"].ToString());
            int overTimeHours = Convert.ToInt16(dt.Rows[i]["OvertimeHours"].ToString());

            String PayStartDate = dt.Rows[i]["StartDate"].ToString();
            String PayEndDate = dt.Rows[i]["EndDate"].ToString();

            calGrossPay(emp_id, regHours, overTimeHours, PayStartDate, PayEndDate);
        }
    }


    public void calGrossPay(int emp_id, int regHours, int OverTimeHours, String PayStartDate, String PayEndDate)
    {
        double hourlyRegPay = 0;
        double hourlyOverTimePay = 0;

        hourlyRegPay = getHourlyPay(emp_id, 1);
        hourlyOverTimePay = getHourlyPay(emp_id, 2);

        double totalRegPay = (regHours * hourlyRegPay);
        double totalOvertimePay = (OverTimeHours * hourlyOverTimePay);
        double grossPay = totalOvertimePay + totalRegPay;

        String query = "Update GrossPay SET GrossPay=" + grossPay + ", RegularHourlypay = " + hourlyRegPay + ", OvertimeHourlypay = " + hourlyOverTimePay + ",TotalRegularpay = " + totalRegPay
            + ",TotalOvertimepay = " + totalOvertimePay + " Where EmpID = " + emp_id + ";";

        //",PayStartDate = " + PayStartDate + ",PayEndDate = " + PayEndDate +

        int result = DataBaseUtility.Execute(ident, query);

        if (result == 1)
        {
            // MessageBox.Show("Check Access Database file is Open. \n" + " Gross Pay could not be calculated for Employee " + emp_id);
        }
    }

    private static double getHourlyPay(int emp_id, int p)
    {
        string query = String.Format("select RegularHourlyPay,Overtimepay from EmployeeBenefits e,Applicants_Details a where " +
       " e.EmpID={0} AND e.IntRef = a.EmpID ", emp_id);

        //string query = String.Format("select IntRef FROM EmployeeBenefits_Details where EmpID = {0} ", emp_id);
        //DataTable dtgetIntRef = DataBaseUtility.GetTable(query);

        //int interef = Convert.ToInt32(dtgetIntRef.Rows[0]);
        //string query1 = String.Format("select RegularHourlyPay,Overtimepay FROM Applicants_Details where EmpID = {0} ", interef);
        double hourlyRate = 0;
        try
        {
            DataTable dtGetHourlyRate = DataBaseUtility.GetTable(query);

            

            if (p == 1)
            {
                hourlyRate = Convert.ToDouble(dtGetHourlyRate.Rows[0].ItemArray[0]);
            }
            else if (p == 2)
            {
                hourlyRate = Convert.ToDouble(dtGetHourlyRate.Rows[0].ItemArray[1]);
            }
            else
            {
                hourlyRate = 0;
            }


            return hourlyRate;
        }

        catch(Exception e)
        {
          return hourlyRate = 0;
        }
        
    }

    public void calNetPay()
    {
        string query = String.Format("select * from {0} order by DocNum", "GrossPay");
        DataTable dtGrossPay = DataBaseUtility.GetTable(query);
        int emp_id = 0;
        double grossPay = 0, netPay = 0;

        for (int i = 0; i < dtGrossPay.Rows.Count; i++)
        {
            emp_id = Convert.ToInt16(dtGrossPay.Rows[i]["EmpID"].ToString());
            grossPay = Convert.ToDouble(dtGrossPay.Rows[i]["GrossPay"].ToString());
            double deductions = getDeductions(emp_id);
            netPay = grossPay - deductions;
            String query1 = "Update NetPay SET NetPay=" + netPay + ", Deductions =" + deductions + ", Grosspay =" + grossPay + " Where EmpID = " + emp_id + ";";

            int result = DataBaseUtility.Execute(ident, query1);
            if (result == 1)
            {
                // MessageBox.Show("Check Access Database file is Open. \n" + " Gross Pay could not be calculated for Employee " + emp_id);
            }
        }
    }

    public double getDeductions(int emp_id)
    {
        string query1 = String.Format("select * from {0} where EmpID={1} order by DocNum", "Deductions", emp_id);
        DataTable dtDeductions = DataBaseUtility.GetTable(query1);
        double deduction = 0;

        if (dtDeductions != null && dtDeductions.Rows.Count > 0)
        {
            deduction = Convert.ToDouble(dtDeductions.Rows[0]["Deductions"].ToString());
        }
        return deduction;
    }

    public void calDeductions()
    {
        string query = String.Format("select * from {0} order by DocNum", "Deductions");
        DataTable dtDeductions = DataBaseUtility.GetTable(query);
        int emp_id = 0;
        for (int i = 0; i < dtDeductions.Rows.Count; i++)
        {
            emp_id = Convert.ToInt16(dtDeductions.Rows[i]["EmpID"].ToString());

            double deductionPercent = getDeductionsPercentage(emp_id);
            double grsPay = getGrossPay(emp_id);

            double deductionAmt = grsPay * (deductionPercent / 100);
            String query1 = "Update Deductions SET Deductions=" + deductionAmt + " Where EmpID = " + emp_id + ";";
            int result = DataBaseUtility.Execute(ident, query1);
            if (result == 1)
            {
                //  MessageBox.Show("Check Access Database file is Open. \n" + " Deductions could not be calculated for Employee " + emp_id);
            }
        }
    }

    public void calDeductionsDetails()
    {
        string query = String.Format("select * from {0} order by DocNum", "Deductions_Details");
        DataTable dtDeductionsDetails = DataBaseUtility.GetTable(query);
        int emp_id = 0;
        for (int i = 0; i < dtDeductionsDetails.Rows.Count; i++)
        {
            emp_id = Convert.ToInt16(dtDeductionsDetails.Rows[i]["EmpID"].ToString());
            int detailID = Convert.ToInt16(dtDeductionsDetails.Rows[i]["DetailID"].ToString());
            double deductionDetailPercentage = getDeductionsDetailPercentage(emp_id, detailID);
            double grsPay = getGrossPay(emp_id);

            double deductionDetailAmt = grsPay * (deductionDetailPercentage / 100);
            String query1 = "Update Deductions_Details SET Deductions=" + deductionDetailAmt + " Where EmpID = " + emp_id + " AND DetailID= " + detailID + " ;";
            int result = DataBaseUtility.Execute(ident, query1);
            if (result == 1)
            {

                //  MessageBox.Show("Check Access Database file is Open. \n" + " Deductions could not be calculated for Employee " + emp_id);
            }
        }
    }

    public double getDeductionsDetailPercentage(int emp_id, int detail_ID)
    {
        string query1 = String.Format("select * from {0} where EmpID={1} AND DetailID={2} order by DocNum", "EmployeeBenefits_Details", emp_id, detail_ID);
        DataTable dtDeductionsDetailPercentage = DataBaseUtility.GetTable(query1);
        double deductionDetailPercentage = 0;

        if (dtDeductionsDetailPercentage != null && dtDeductionsDetailPercentage.Rows.Count > 0)
        {
            deductionDetailPercentage = Convert.ToDouble(dtDeductionsDetailPercentage.Rows[0]["Benefits_Percent"].ToString());
        }
        return deductionDetailPercentage;
    }

    public double getDeductionsPercentage(int emp_id)
    {
        string query1 = String.Format("select * from {0} where EmpID={1}  order by DocNum", "EmployeeBenefits", emp_id);
        DataTable dtDeductionsPercentage = DataBaseUtility.GetTable(query1);
        double deductionPercentage = 0;

        if (dtDeductionsPercentage != null && dtDeductionsPercentage.Rows.Count > 0)
        {
            deductionPercentage = Convert.ToDouble(dtDeductionsPercentage.Rows[0]["Benefits_Percent"].ToString());
        }
        return deductionPercentage;
    }
    public double getGrossPay(int emp_id)
    {
        string query2 = String.Format("select * from {0} where EmpID={1} order by DocNum", "GrossPay", emp_id);
        DataTable dtGrsPay = DataBaseUtility.GetTable(query2);
        double grsPay = 0;

        if (dtGrsPay != null && dtGrsPay.Rows.Count > 0)
        {
            grsPay = Convert.ToDouble(dtGrsPay.Rows[0]["GrossPay"].ToString());
        }
        return grsPay;
    }

    protected void ImageButtonExportExcel_Click(object sender, ImageClickEventArgs e)
    {
        string query = String.Format("select * from {0} order by DocNum", "GrossPay");
        DataTable dtExcel = DataBaseUtility.GetTable(query);

        string queryNetPay = String.Format("select * from {0} order by DocNum", "NetPay");
        DataTable dtExcelNetPay = DataBaseUtility.GetTable(queryNetPay);

        string queryTimeCard = String.Format("select * from {0} order by DocNum", "TimeCards");
        DataTable dtExcelTimeCard = DataBaseUtility.GetTable(queryTimeCard);

        Excel.Application xlApp;
        Excel.Workbook xlWorkBook;
        Excel.Worksheet xlWorkSheet;
        Excel.Worksheet xlWorkSheet2;
        Excel.Worksheet xlWorkSheet3;

        object misValue = System.Reflection.Missing.Value;
        xlApp = new Excel.Application();
        xlWorkBook = xlApp.Workbooks.Add(misValue);
        
        var xlSheets = xlWorkBook.Sheets as Excel.Sheets;
        var xlNewSheet = (Excel.Worksheet)xlSheets.Add(xlSheets[1], Type.Missing, Type.Missing, Type.Missing);
        var xlNewSheet2 = (Excel.Worksheet)xlSheets.Add(xlSheets[2], Type.Missing, Type.Missing, Type.Missing);
        var xlNewSheet3 = (Excel.Worksheet)xlSheets.Add(xlSheets[3], Type.Missing, Type.Missing, Type.Missing);

        xlWorkSheet = xlNewSheet;
        xlWorkSheet2 = xlNewSheet2;
        xlWorkSheet= (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        xlWorkSheet2 = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(2);
        xlWorkSheet3 = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(3);
        
        xlWorkSheet.Name = "Gross Pay";
        xlNewSheet2.Name = "Net Pay";
        xlNewSheet3.Name = "Time Cards";

        int row = 1, col = 1;

        if (row == 1)
        {
            xlWorkSheet.Cells[row, 1] = "Doc Num";
            xlWorkSheet.Cells[row, 2] = "Doc Type";
            xlWorkSheet.Cells[row, 3] = "Emp ID";
            xlWorkSheet.Cells[row, 4] = "Regular Hourly pay";
            xlWorkSheet.Cells[row, 5] = "Overtime Hourly pay";
            xlWorkSheet.Cells[row, 6] = "Total Regular pay";
            xlWorkSheet.Cells[row, 7] = "Pay StartDate";
            xlWorkSheet.Cells[row, 8] = "Pay EndDate";
            xlWorkSheet.Cells[row, 9] = "Total Overtimepay";
            xlWorkSheet.Cells[row, 10] = "GrossPay";
            xlWorkSheet.Cells[row, 11] = "Comments";

            xlWorkSheet2.Cells[row, 1] = "Doc Num";
            xlWorkSheet2.Cells[row, 2] = "Doc Type";
            xlWorkSheet2.Cells[row, 3] = "Emp ID";
            xlWorkSheet2.Cells[row, 4] = "Status";
            xlWorkSheet2.Cells[row, 5] = "Doc Ref";
            xlWorkSheet2.Cells[row, 6] = "Gross pay";
            xlWorkSheet2.Cells[row, 7] = "Pay StartDate";
            xlWorkSheet2.Cells[row, 8] = "Pay EndDate";
            xlWorkSheet2.Cells[row, 9] = "Deductions";
            xlWorkSheet2.Cells[row, 10] = "NetPay";
            xlWorkSheet2.Cells[row, 11] = "Comments";

            xlWorkSheet3.Cells[row, 1] = "Doc Num";
            xlWorkSheet3.Cells[row, 2] = "Doc Type";
            xlWorkSheet3.Cells[row, 3] = "Emp ID";
            xlWorkSheet3.Cells[row, 4] = "Regular Hours";
            xlWorkSheet3.Cells[row, 5] = "Overtime Hours";
            xlWorkSheet3.Cells[row, 6] = "TextValue";
            xlWorkSheet3.Cells[row, 7] = "Start Date";
            xlWorkSheet3.Cells[row, 8] = "End Date";
            xlWorkSheet3.Cells[row, 9] = "Total Hours";
            xlWorkSheet3.Cells[row, 10] = "Other";
            xlWorkSheet3.Cells[row, 11] = "Comments";
            row++;
        }

        for (int i = 0; i < dtExcel.Rows.Count; i++)
        {
            col = 1;
            for (int j = 0; j < dtExcel.Columns.Count; j++)
            {
                xlWorkSheet.Cells[row, col] = dtExcel.Rows[i].ItemArray[j].ToString();
                xlWorkSheet2.Cells[row, col] = dtExcelNetPay.Rows[i].ItemArray[j].ToString();
                xlWorkSheet3.Cells[row, col] = dtExcelTimeCard.Rows[i].ItemArray[j].ToString();
                col++;
            }
            row++;
        }
        xlWorkBook.SaveAs("Payroll_Manager.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
        xlWorkBook.Close(true, misValue, misValue);
        xlApp.Quit();

        releaseObject(xlWorkSheet);
        releaseObject(xlWorkBook);
        releaseObject(xlApp);
        Response.Write("<script type=\"text/javascript\">alert('Excel file created. Excel file is Saved in Documents folder.');</script>");

    }

    private void releaseObject(object obj)
    {
        try
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
        }
        catch (Exception ex)
        {
            obj = null;
            //MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
        }
        finally
        {
            GC.Collect();
        }
    }

    protected void ImageButtonSendEmail_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            MailMessage mM = new MailMessage();
            mM.From = new MailAddress("v.shashidhar2212@hotmail.com");
            mM.To.Add("rolandbaker101@hotmail.com");
            mM.Subject = " sad testing";
            mM.Attachments.Add(new Attachment(@"C:\Users\shashidhar v\Documents\Payroll_Manager.xls"));
            mM.Body = "attachment";
            mM.IsBodyHtml = true;
            SmtpClient sC = new SmtpClient("smtp.live.com");
            sC.Port = 587;
            sC.Credentials = new NetworkCredential("v.shashidhar2212@hotmail.com", "sad@password");
            sC.EnableSsl = true;
            sC.Send(mM);
        }
        catch (Exception ex)
        {
            Response.Write("mailbox unavailable. the server response was 5.7.1 unable to relay for email address");
        }
    }
    protected void ImageButtonChart_Click(object sender, ImageClickEventArgs e)
    {
        IdentityObject ident = (IdentityObject)Session["ident"];

        if(ident.Role.Trim().Equals("Manager"))
        {
            Response.Redirect("~/Applications/Payroll/ChartsManager.aspx");
        }
        else
        {
            Response.Redirect("~/Applications/Payroll/ChartEmployee.aspx");
        }
    }
}