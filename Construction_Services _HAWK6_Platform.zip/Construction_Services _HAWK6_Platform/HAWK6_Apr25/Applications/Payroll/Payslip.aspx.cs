﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_Payroll_Payalip : System.Web.UI.Page
{
    public int grossPay = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        IdentityObject ident = (IdentityObject)Session["ident"];
        if(ident!=null)
        { 
        string queryEmp = String.Format("select * from Employees where DocNum="+ident.UserID);
        DataTable dtEmp = DataBaseUtility.GetTable(queryEmp);

        for (int i = 0; i < dtEmp.Rows.Count; i++)
        {
            textBoxEmployeeId.Text =dtEmp.Rows[i]["DocNum"].ToString();
            textBoxFirstName.Text =dtEmp.Rows[i]["FirstName"].ToString();
            textBoxLastname.Text= dtEmp.Rows[i]["LastName"].ToString();
            TextBoxRole.Text = dtEmp.Rows[i]["Role"].ToString();
        }

        string queryTimecard = String.Format("select * from TimeCards where EmpID=" + ident.UserID);
        DataTable dtTimeCard = DataBaseUtility.GetTable(queryTimecard);

        for (int i = 0; i < dtTimeCard.Rows.Count; i++)
        {
            textBoxRegularHours.Text = dtTimeCard.Rows[i]["RegularHours"].ToString();
            textBoxOvertimeHours.Text = dtTimeCard.Rows[i]["OvertimeHours"].ToString();
            textBoxTotalHours.Text = dtTimeCard.Rows[i]["TotalHours"].ToString();
        }

        string queryNetPay = String.Format("select * from NetPay where EmpID=" + ident.UserID);
        DataTable dtNetPay = DataBaseUtility.GetTable(queryNetPay);

        for (int i = 0; i < dtNetPay.Rows.Count; i++)
        {
            textBoxGrossPay.Text = dtNetPay.Rows[i]["Grosspay"].ToString();
            grossPay = Convert.ToInt32(textBoxGrossPay.Text);
            LabelTotalBenefits.Text="Total Deductions";
            textBoxTotalBenefits.Text = dtNetPay.Rows[i]["Deductions"].ToString();
            textBoxNetPay.Text = dtNetPay.Rows[i]["NetPay"].ToString();
        }

        string queryDeductions = String.Format("select * from EmployeeBenefits_Details where EmpID=" + ident.UserID);
        DataTable dtqueryDeductions = DataBaseUtility.GetTable(queryDeductions);

        for (int i = 0; i < dtqueryDeductions.Rows.Count; i++)
        {
            if(i==0)
            {
                LabelBenefit1.Text = dtqueryDeductions.Rows[i]["Comment"].ToString();
                textBoxBenefit1.Text = ( (grossPay/100)* Convert.ToInt64(dtqueryDeductions.Rows[i]["Benefits_percent"])).ToString();
            }
            if (i==1)
            {
                LabelBenefit2.Text = dtqueryDeductions.Rows[i]["Comment"].ToString();
                textBoxBenefit2.Text = ((grossPay/100) * Convert.ToInt64(dtqueryDeductions.Rows[i]["Benefits_percent"])).ToString();
            }
            if (i==2)
            {
                LabelBenefit3.Text = dtqueryDeductions.Rows[i]["Comment"].ToString();
                textBoxBenefit3.Text = ((grossPay/100) * Convert.ToInt64(dtqueryDeductions.Rows[i]["Benefits_percent"])).ToString();
            }

            if(dtqueryDeductions.Rows.Count < 3)
            {
                LabelBenefit3.Text = "Others";
                textBoxBenefit3.Text = Convert.ToString("0");
            }
        }
      }
    }
}