﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applications_Infrastructure_RoleManagement : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    if (!IsPostBack)
    {
      if (Roles.GetAllRoles() != null)
      {
        lblError.Visible = false;
        lblError1.Visible = false;
        lblError2.Visible = false;
        dlstUserRole.DataSource = Roles.GetAllRoles();
        dlstUserRole.DataBind();
      }
    }
  }

  protected void btnAddNewUser_Click(object sender, EventArgs e)
  {
    if (String.IsNullOrWhiteSpace(txtNewUserName.Text))
    {
      lblError.Text = "*Please enter user name";
      lblError.Visible = true;
      return;
    }
    if (String.IsNullOrWhiteSpace(txtNewUserPass.Text))
    {
      lblError.Text = "*Please enter user pass";
      lblError.Visible = true;
      return;
    }
    if (String.IsNullOrWhiteSpace(txtNewUserEmail.Text))
    {
      lblError.Text = "*Please enter user email";
      lblError.Visible = true;
      return;
    }

    string newUserName = txtNewUserName.Text;
    string newUserPass = txtNewUserPass.Text;
    string newUserEmail = txtNewUserEmail.Text;

    MembershipUser mu = Membership.GetUser(newUserName);
    if (mu != null)
    {
      lblError.Text= "*Member already exits.";
      lblError.Visible = true;
      return;
    }

    // Create the user
    try
    {
      mu = Membership.CreateUser(newUserName, newUserPass, newUserEmail);
    }
    catch (Exception ex)
    {
      lblError.Text = "*Cannot Create User.";
      lblError.Visible = true;
    }

    if (mu != null)
    {
      lblError.Text = "*User created sucessfully.";
      lblError.Visible = true;
      // just for grins, prevent user from logging in
      mu.IsApproved = false;
      Membership.UpdateUser(mu);
    }
  }

  protected void btnAddRole_Click(object sender, EventArgs e)
  {
    string newRole = txtNewUserRole.Text;

    if (!String.IsNullOrWhiteSpace(newRole))
    {
      if (Roles.RoleExists(newRole))
      {
        lblError1.Text = "*Role is already exists";
        lblError1.Visible = true;
        return;
      }
      Roles.CreateRole(newRole);
      lblError1.Text = "*Role created successfully";
      lblError1.Visible = true;
      txtNewUserRole.Text = "";
      dlstUserRole.DataSource = Roles.GetAllRoles();
      dlstUserRole.DataBind();
    }
    else
    {
      lblError1.Text = "*Please enter New Role";
      lblError1.Visible = true;
    }
  }

  protected void btnRemoveRole_Click(object sender, EventArgs e)
  {
    string removedRole = txtNewUserRole.Text;

    if (!String.IsNullOrWhiteSpace(removedRole))
    {
      if (Roles.RoleExists(removedRole))
      {
        Roles.DeleteRole(removedRole);
        lblError1.Text = "*Role is removed sucessfully";
        lblError1.Visible = true;
        dlstUserRole.DataSource = Roles.GetAllRoles();
        dlstUserRole.DataBind();
        txtNewUserRole.Text = "";
      }
      else
      {
        lblError1.Text = "*Role does not exists";
        lblError1.Visible = true;
      }
    }
    else
    {
      lblError1.Text = "*Please enter Role to remove";
      lblError1.Visible = true;
    }
  }

  protected void btnAddMembership_Click(object sender, EventArgs e)
  {
    string newMembership = txtUserName.Text;
    if (String.IsNullOrWhiteSpace(txtUserName.Text))
    {
      lblError2.Text = "*Please enter User Name";
      lblError2.Visible = true;
    }
    else
    {
      MembershipUser mu = Membership.GetUser(newMembership);
      if (mu == null)
      {
        lblError2.Text = "*User Name not exists";
        lblError2.Visible = true;
        return;
      }

      if (Roles.IsUserInRole(newMembership, dlstUserRole.SelectedValue))
      {
        lblError2.Text = "*User Name is already in role";
        lblError2.Visible = true;
        return;
      }

      Roles.AddUserToRole(newMembership, dlstUserRole.SelectedValue);
      lblError2.Text = "*Add User name to Role succesfully!";
      lblError2.Visible = true;
    }
  }

  protected void btnRemoveMembership_Click(object sender, EventArgs e)
  {
    string removeMembership = txtUserName.Text;

    if (String.IsNullOrWhiteSpace(txtUserName.Text))
    {
      lblError2.Text = "*Please enter User Name to remove";
      lblError2.Visible = true;
    }
    else
    {
      MembershipUser mu = Membership.GetUser(removeMembership);
      if (mu == null)
      {
        lblError2.Text = "*User Name not exists";
        lblError2.Visible = true;
        return;
      }

      if (Roles.IsUserInRole(removeMembership, dlstUserRole.SelectedValue))
      {
        Roles.RemoveUserFromRole(removeMembership, dlstUserRole.SelectedValue);
        lblError2.Text = "*Remove User Name from Role sucessfully";
        lblError2.Visible = true;
        return;
      }
      else
      {
        lblError2.Text = "*User name is not in Role";
        lblError2.Visible = true;
      }
    }
  }

  protected void import_Click(object sender, EventArgs e)
  {
      string _connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source =|DataDirectory|\PACS.accdb";

      OleDbConnection con = new OleDbConnection(_connectionString);
      con.Open();
      var sqlCommand = String.Format("Select * from Employees where DocNum in (102, 103)");
      OleDbCommand cmd = new OleDbCommand(sqlCommand, con);
      OleDbDataReader dr = cmd.ExecuteReader();

      if (dr.HasRows)
      {
          while (dr.Read())
          {
              string email = dr.GetString(12);
              string username = dr.GetInt16(0).ToString();
              string password = dr.GetInt16(0).ToString() + "\\" + dr.GetString(3);
              string question = "What is 2 + 2?";
              string answer = "4";
              System.Web.Security.MembershipCreateStatus status;
              System.Web.Security.Membership.CreateUser(username, password, email, question, answer, true, out status);
              if (status == System.Web.Security.MembershipCreateStatus.Success)
              {
                  Roles.AddUserToRole(dr.GetInt16(0).ToString(), "Application");
              }
          }
      }
  }
}