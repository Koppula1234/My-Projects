﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPages_MasterPage_Template1 : DataBaseUtilityMaster
{
  protected void Page_Load(object sender, EventArgs e)
  {
      if (!IsPostBack)
      {
          if (HttpContext.Current.User.Identity.IsAuthenticated)
          {
              var username = HttpContext.Current.User.Identity.Name.Split('|')[0];
              Label lblUserName = ((Label)(this.LoginView1.FindControl("lblName")));

              if (username != null & username != "")
              {

                  try
                  {
                      con.Open();
                      var sqlCommand = String.Format("Select * from Employees where DocNum = {0}", username);
                      cmd = new OleDbCommand(sqlCommand, con);
                      dr = cmd.ExecuteReader();
                      //IdentityObject ident;

                      if (dr.HasRows)
                      {
                          while (dr.Read())
                          {
                              lblUserName.Text = String.Format("{0} {1} ({2})", dr.GetString(2), dr.GetString(3), dr.GetString(14));
                              ident = new IdentityObject(dr.GetInt16(0).ToString(), dr.GetString(3), dr.GetString(14), Convert.ToInt32(dr.GetValue(15)), Convert.ToInt32(dr.GetValue(13)));
                              FormsAuthentication.SetAuthCookie(((short)dr.GetInt16(0)).ToString() + "|" + dr.GetString(3) + "|" + dr.GetString(14) + "|" + Convert.ToInt32(dr.GetValue(15)) + "|" + Convert.ToInt32(dr.GetValue(13)), false);
                              Session["ident"] = ident;
                          }
                      }
                  }
                  catch (Exception ex)
                  {
                      lblUserName.Text = String.Format("{0}", username);
                      Session["username"] = username;
                  }
                  finally
                  {
                      try
                      {
                          if (dr.HasRows)
                          {
                              con.Close();
                          }
                          else
                          {

                          }
                      }
                      catch (Exception ex)
                      {

                      }
                  }
              }
          }
      }
  }
}
