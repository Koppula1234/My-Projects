﻿Imports System.Data.SqlClient
Imports System
Partial Class puzanalysis
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("select pzid from puztime", con)
                Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                DropDownList1.Items.Clear()
                DropDownList1.Items.Add("Select")
                While dr.Read()
                    DropDownList1.Items.Add(dr.GetValue(0))
                End While
                dr.Close()
            Catch ex As Exception

            End Try
            con.Close()
        End If
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        Try
            con.Open()
            Dim cans As String
            Dim a1, a2 As Integer
            Dim cmd As New SqlCommand("select sid,qno,pquest,ans,nhints,tmtkn,pcans,avgtm,abavgtm from puztime,puzzle where pzid=" + DropDownList1.Text + " and qno=qid", con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SingleRow)
            If dr.Read() Then
                TextBox1.Text = dr.GetValue(0)
                TextBox2.Text = dr.GetValue(1)
                TextBox3.Text = dr.GetValue(2)
                TextBox4.Text = dr.GetValue(3)
                TextBox5.Text = dr.GetValue(4)
                TextBox6.Text = dr.GetValue(5)
                cans = dr.GetValue(6)
                a1 = dr.GetValue(7)
                a2 = dr.GetValue(8)
            End If
            dr.Close()
            Dim ans1 As String
            Dim cmd9 As New SqlCommand("select pcans from puzzle where qid=" + TextBox2.Text, con)
            Dim dr9 As SqlDataReader = cmd9.ExecuteReader(Data.CommandBehavior.SingleRow)
            If dr9.Read() Then
                'If cans = 1 Then
                ans1 = dr9.GetValue(0)
                'End If
                'If cans = 2 Then
                '    ans1 = dr9.GetValue(1)
                'End If
                'If cans = 3 Then
                '    ans1 = dr9.GetValue(2)
                'End If

            End If
            dr9.Close()

            Dim tm As Integer
            tm = TextBox6.Text
            'Response.Write(tm & ":" & a1 & ":" & a2 & ":" & ans1)
            If TextBox4.Text = ans1 Then
                If TextBox5.Text = 0 Then

                    If tm >= a1 Then
                        TextBox7.Text = "Poor"
                    Else
                        If tm > a2 And tm <= a1 Then
                            TextBox7.Text = "Average"
                        Else
                            If a2 > tm Then
                                TextBox7.Text = "Good"
                            End If
                        End If
                    End If
                End If
                If TextBox5.Text = 1 Then
                    If tm <= a1 Then
                        TextBox7.Text = "Poor"
                    Else
                        If tm >= a2 / 2 And tm <= a1 Then
                            TextBox7.Text = "Average"
                        Else
                            If a2 - 10 >= tm Then
                                TextBox7.Text = "Good"
                            End If
                        End If
                    End If
                End If
                If TextBox5.Text > 1 Then
                    If tm < a1 Then
                        TextBox7.Text = "Poor"
                    Else
                        If tm >= a1 And tm <= a2 / 2 Then
                            TextBox7.Text = "Poor"
                        Else
                            If a2 + 10 > tm Then
                                TextBox7.Text = "Average"
                            End If
                        End If
                    End If
                End If
            Else
                TextBox7.Text = "Poor"
            End If
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        con.Close()
    End Sub
End Class
