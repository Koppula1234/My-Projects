﻿Imports System.Data.SqlClient
Imports System
Partial Class exanalysis
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Dim texid As Integer
    Dim fg As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub

    Protected Sub ListBox6_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox6.SelectedIndexChanged
        Dim i As Integer
        ListBox4.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        Dim fg As Integer
        fg = Session.Item("flag")
        If fg = 1001 Then
            'Response.Write("select sttm,edtm from timeinfo where exid=10000 and qno=" & ListBox1.Items(ListBox6.SelectedIndex).Text)
            Try
                con.Open()
                Dim cmd31 As New SqlCommand("select quest from questionaire where qid=" & ListBox6.Text, con)
                Dim dr31 As SqlDataReader = cmd31.ExecuteReader(Data.CommandBehavior.SingleRow)

                If dr31.Read() Then
                    ListBox7.Items.Clear()
                    ListBox7.Items.Add(dr31.GetValue(0))
                End If
                dr31.Close()

                'For i = 0 To ListBox1.Items.Count - 1
                Dim cmd3 As New SqlCommand("select sttm,edtm from timeinfo where exid=" & TextBox1.Text & " and qno=" & ListBox1.Items(ListBox6.SelectedIndex).Text, con)
                Dim dr3 As SqlDataReader = cmd3.ExecuteReader(Data.CommandBehavior.SingleRow)

                If dr3.Read() Then
                    Dim d1, d2 As Date
                    d1 = dr3.GetValue(0)
                    d2 = dr3.GetValue(1)
                    ListBox2.Items.Add(d1)
                    ListBox3.Items.Add(d2)
                    ListBox4.Items.Add(DateDiff(DateInterval.Second, d1, d2))

                End If
                dr3.Close()
                Dim cmd4 As New SqlCommand("select sttm,edtm from revise where exid=" & TextBox1.Text & " and aqno=" & ListBox6.Text, con)
                Dim dr4 As SqlDataReader = cmd4.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                While dr4.Read()
                    Dim d1, d2 As Date
                    d1 = dr4.GetValue(0)
                    d2 = dr4.GetValue(1)
                    ListBox2.Items.Add(d1)
                    ListBox3.Items.Add(d2)
                    ListBox4.Items.Add(DateDiff(DateInterval.Second, d1, d2))

                End While
                dr4.Close()
                'Next

                'For i = 0 To ListBox2.Items.Count - 1
                '    Dim d1, d2 As Date
                '    d1 = ListBox2.Items(i).Text
                '    d2 = ListBox3.Items(i).Text
                '    ListBox4.Items.Add(DateDiff(DateInterval.Second, d1, d2))
                '    Response.Write(d1.Subtract(d2))
                'Next
            Catch ex As Exception
                Response.Write(ex.Message)
            End Try
            con.Close()
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        'If Not Page.IsPostBack() Then
        'texid = Session.Item("examid")
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()
        ListBox7.Items.Clear()
        texid = TextBox1.Text
        Dim i As Integer
        Try
            con.Open()
            Dim cmd2 As New SqlCommand("select distinct qno from timeinfo where exid=" & texid, con)
            Dim dr2 As SqlDataReader = cmd2.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            ListBox1.Items.Clear()
            While dr2.Read()
                ListBox1.Items.Add(dr2.GetValue(0))
            End While
            dr2.Close()
            ListBox6.Items.Clear()

            For i = 0 To ListBox1.Items.Count - 1
                Dim cmd1 As New SqlCommand("select aqno from exam where exid=" & texid & " and qno=" & ListBox1.Items(i).Text, con)
                Dim dr1 As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                If dr1.Read() Then
                    fg = fg + 1
                    ListBox6.Items.Add(dr1.GetValue(0))
                End If
                dr1.Close()
            Next

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        con.Close()
        con.Open()
        ListBox5.Items.Clear()
        Dim dd As Integer

        For i = 0 To ListBox1.Items.Count - 1

            Dim cmd3 As New SqlCommand("select sttm,edtm from timeinfo where exid=" & TextBox1.Text & " and qno=" & ListBox1.Items(i).Text, con)
            Dim dr3 As SqlDataReader = cmd3.ExecuteReader(Data.CommandBehavior.SingleRow)

            If dr3.Read() Then
                Dim d1, d2 As Date
                d1 = dr3.GetValue(0)
                d2 = dr3.GetValue(1)
                dd = (DateDiff(DateInterval.Second, d1, d2))

            End If
            dr3.Close()
            Dim cmd4 As New SqlCommand("select sttm,edtm from revise where exid=" & TextBox1.Text & " and aqno=" & ListBox6.Items(i).Text, con)
            Dim dr4 As SqlDataReader = cmd4.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            While dr4.Read()
                Dim d1, d2 As Date
                d1 = dr4.GetValue(0)
                d2 = dr4.GetValue(1)
                dd = dd + (DateDiff(DateInterval.Second, d1, d2))
            End While
            dr4.Close()

            Dim cmd6 As New SqlCommand("select avgtm,abavgtm from questionaire where qid=" & ListBox6.Items(i).Text, con)
            Dim dr6 As SqlDataReader = cmd6.ExecuteReader(Data.CommandBehavior.SingleRow)
            Dim tm As String
            If dr6.Read() Then
                Dim a1, a2 As Integer
                a1 = dr6.GetValue(0)
                a2 = dr6.GetValue(1)
                If dd > a1 Then
                    tm = "Poor"
                Else
                    If dd > a2 And dd < a1 Then
                        tm = "Average"
                    Else
                        tm = "Good"
                    End If
                End If
            End If
            dr6.Close()

            ListBox5.Items.Add(ListBox1.Items(i).Text + " ===> " + dd.ToString() + " ===> " + tm)
        Next
        fg = 1001
        Session.Add("flag", fg)
        'End If
    End Sub
End Class
