﻿Imports System.Data.SqlClient
Partial Class Tutorial
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Dim nvno As Integer
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        updateedtm()
        Response.Redirect("nettutor.aspx")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       
        'Label1.Text = "User : " & sid & ", Date : " & dt & ", Time : " & tm
    End Sub

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        Dim sid As String
        sid = Session.Item("lsid")
        Dim dt As String = Date.Now
        'Dim tm As Date = Date.Now.ToShortTimeString()
        Try
            con.Open()
            Dim cmd2 As New SqlCommand("select max(vno) from tutvisit where pageid='" & HiddenField1.Value & "'", con)
            Dim dr2 As SqlDataReader = cmd2.ExecuteReader(Data.CommandBehavior.SingleResult)
            Try
                If dr2.Read() Then
                    nvno = dr2.GetValue(0) + 1
                End If
            Catch ex As Exception
                nvno = 1
            End Try
            dr2.Close()
            Dim cmd As New SqlCommand("insert into tutvisit values('" & HiddenField1.Value & "'," & sid & ",'" & dt & "',' ',' ',' '," & nvno & ")", con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try
        con.Close()
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        'Dim sid As String
        'sid = Session.Item("lsid")
        'Dim dt As String = Date.Now
        ''Dim tm As Date = Date.Now.ToShortTimeString()
        'Try
        '    con.Open()
        '    Dim cmd As New SqlCommand("update tutvisit set edtm='" & dt & "' where pageid='" & HiddenField1.Value & "' and edtm=' '", con)
        '    cmd.ExecuteNonQuery()

        'Catch ex As Exception
        '    'Response.Write(ex.Message)
        'End Try
        'con.Close()

    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        updateedtm()
        'Response.Redirect("Default.aspx")
        Response.Write("<script>window.open('home.htm','_top');</script>")
    End Sub

    Public Sub updateedtm()
        Dim sid As String
        sid = Session.Item("lsid")
        Dim dt As String = Date.Now
        'Dim tm As Date = Date.Now.ToShortTimeString()
        Try
            con.Open()
            Dim cmd As New SqlCommand("update tutvisit set edtm='" & dt & "' where pageid='" & HiddenField1.Value & "' and edtm=' '", con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            'Response.Write(ex.Message)
        End Try
        con.Close()
    End Sub
End Class
