﻿Imports System.Data.SqlClient
Partial Class _Default
    Inherits System.Web.UI.Page

    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            con.Open()
            If RadioButton2.Checked = True Then
                Dim cmd As New SqlCommand("select * from students where sid=" & TextBox1.Text & " and pwd='" & TextBox2.Text & "'", con)
                Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr.Read() Then
                    Session.Add("lsid", TextBox1.Text)
                    Response.Redirect("SOptions.aspx")
                Else
                    Label3.Text = "Login Failed! Try Again...."
                    Label3.Visible = True
                End If
            Else
                Dim cmd As New SqlCommand("select * from admins where uid='" & TextBox1.Text & "' and pwd='" & TextBox2.Text & "'", con)
                Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr.Read() Then
                    Response.Redirect("AOptions.aspx")
                Else
                    Label3.Text = "Login Failed! Try Again...."
                    Label3.Visible = True
                End If
            End If
        Catch ex As Exception
            Label3.Text = "Login Failed! Try Again...."
            Label3.Visible = True
        End Try
        con.Close()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
End Class
