﻿
Partial Class SOptions
    Inherits System.Web.UI.Page

End Class
