﻿
Partial Class AOptions
    Inherits System.Web.UI.Page

End Class
