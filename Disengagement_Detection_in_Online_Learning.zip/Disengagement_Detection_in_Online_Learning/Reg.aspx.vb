﻿Imports System.Data.SqlClient
Partial Class Reg
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Data Source=SYSTEM;Initial Catalog=disdetdb;User ID=sa;Password=a")
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim nsno As Integer
        Try
            con.Open()
            nsno = 1000
            Try
                Dim cmd1 As New SqlCommand("select max(sid) from students", con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    nsno = dr.GetValue(0) + 1
                Else
                    nsno = 1000
                End If
                dr.Close()
            Catch ex As Exception
                nsno = 1000
                'Label5.Text = ex.Message
            End Try

            Dim cmd2 As New SqlCommand("insert into students values(" & nsno & ",'" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')", con)
            cmd2.ExecuteNonQuery()

            Label5.Text = "Student Registered Successfully with ID " & nsno
            Button1.Enabled = False
        Catch ex As Exception
            Label5.Text = "Student With this ID already exists! Try Another."
        End Try
        con.Close()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TextBox5.Text = Date.Today.ToShortDateString()
    End Sub
End Class
