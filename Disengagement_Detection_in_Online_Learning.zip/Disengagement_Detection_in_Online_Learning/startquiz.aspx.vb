﻿Imports System.Data.SqlClient
Imports System
Partial Class startquiz
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Dim fg As Integer
    Dim randomvalue As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TextBox1.Text = Session.Item("lsid")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox8.Text = 0
        Dim mqid As Integer
        Dim nexid As Integer
        Try
            con.Open()
            nexid = 10000
            Try
                Dim cmd1 As New SqlCommand("select max(pzid) from puztime", con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    nexid = dr.GetValue(0) + 1
                Else
                    nexid = 10000
                End If
                dr.Close()
            Catch ex As Exception
                nexid = 10000
                'Label5.Text = ex.Message
            End Try
        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
        con.Close()

        '''
        Try
            con.Open()

            Try
                Dim cmd1 As New SqlCommand("select max(qid) from puzzle", con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    mqid = dr.GetValue(0) + 1
                Else
                    mqid = 1001
                End If
                dr.Close()
            Catch ex As Exception
                mqid = 1001
                'Label5.Text = ex.Message
            End Try
        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
        con.Close()
        ''''




        TextBox6.Text = nexid
        Session.Add("examid", TextBox6.Text)
        TextBox2.Text = 25
        Timer1.Enabled = True


        Dim j, k As Integer
        'randomvalue = CInt(Int((5) * Rnd(5) + 1))
        Dim fg As Integer = 0
        j = 0



        Dim nv As Integer
        nv = RandomNumber(1001, mqid)
        fg = 0

        Try
            con.Open()
            Dim cmd As New SqlCommand("select * from puzzle where qid=" & nv, con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            If dr.Read() Then
                TextBox3.Text = dr.GetValue(0)
                TextBox4.Text = dr.GetValue(1)
            End If

        Catch ex As Exception
            Label6.Text = ex.Message()
        End Try
        con.Close()
        Button1.Enabled = False
    End Sub

    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        TextBox2.Text = TextBox2.Text - 1

        If (TextBox2.Text = 0) Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("insert into puztime values(" & TextBox1.Text & "," & TextBox6.Text & "," & TextBox3.Text & ",'" & TextBox11.Text & "'," & TextBox8.Text & "," & (25 - TextBox2.Text) & ")", con)
                cmd.ExecuteNonQuery()
                
            Catch ex As Exception
                Label6.Text = ex.Message
            End Try
            con.Close()
            Timer1.Enabled = False
            Response.Redirect("presults.aspx")
        End If


    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim hu As Integer
        If TextBox8.Text < 3 Then
            TextBox8.Text = TextBox8.Text + 1
            hu = TextBox8.Text
            'If TextBox5.Text < 2 Then

            con.Open()
            Dim cmd6 As New SqlCommand("select * from puzzle where  qid=" & TextBox3.Text, con)
            Dim dr6 As SqlDataReader = cmd6.ExecuteReader(Data.CommandBehavior.SingleRow)
            If dr6.Read() Then
                If (hu = 1) Then
                    TextBox12.Text = dr6.GetValue(3)
                Else
                    If (hu = 2) Then
                        TextBox12.Text = TextBox12.Text & Chr(13) & dr6.GetValue(4)
                    Else
                        If (hu = 3) Then
                            TextBox12.Text = TextBox12.Text & Chr(13) & dr6.GetValue(5)
                        Else
                            Label6.Text = "You have used up all the hints."
                        End If
                    End If
                End If
            End If
            con.Close()
        Else
            Label6.Text = "You have used up all the hints."
        End If

        '    TextBox3.Text = TextBox3.Text + 1
        '    TextBox7.Text = "1"
        '    TextBox8.Text = "1"
        '    Label6.Text = ""
        '    TextBox5.Text = TextBox5.Text + 1
        '    Try
        '        con.Open()

        '        Dim cmd As New SqlCommand("select * from questionaire where qid=" & ListBox1.Items(TextBox5.Text).Text, con)
        '        Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
        '        Dim i As Integer = 1
        '        If dr.Read() Then
        '            TextBox4.Text = dr.GetValue(1)
        '            RadioButton1.Text = dr.GetValue(3)
        '            RadioButton2.Text = dr.GetValue(4)
        '            RadioButton3.Text = dr.GetValue(5)
        '            RadioButton4.Text = dr.GetValue(6)
        '        End If
        '        dr.Close()

        '        Dim cmd2 As New SqlCommand("insert into exam values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",0,1,1" & "," & ListBox1.Items(TextBox5.Text).ToString() & ")", con)
        '        cmd2.ExecuteNonQuery()
        '    Catch ex As Exception
        '        Label6.Text = ex.Message()
        '    End Try
        '    con.Close()

        '    Try
        '        con.Open()
        '        Dim fg As Integer
        '        Dim cmd5 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
        '        Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
        '        If dr5.Read() Then
        '            dr5.Close()
        '            Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
        '            cmd.ExecuteNonQuery()
        '        Else
        '            dr5.Close()
        '            Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
        '            cmd.ExecuteNonQuery()
        '        End If
        '    Catch ex As Exception
        '        Label6.Text = ex.Message
        '    End Try
        '    con.Close()
        'Else
        '    Label6.Text = "You have reached the last question"
        'End If


    End Sub

    Public Function RandomNumber(ByVal MaxNumber As Integer, Optional ByVal MinNumber As Integer = 0) As Integer

        'initialize random number generator
        Dim r As New Random(System.DateTime.Now.Millisecond)

        'if passed incorrect arguments, swap them
        'can also throw exception or return 0

        If MinNumber > MaxNumber Then
            Dim t As Integer = MinNumber
            MinNumber = MaxNumber
            MaxNumber = t
        End If

        Return r.Next(MinNumber, MaxNumber)

    End Function

    


    

    Public Sub incr_visit()
        Dim nato As Integer
        'Try
        '    con.Open()
        '    nato = 1
        '    Try
        '        Dim cmd1 As New SqlCommand("select max(atno) from exam where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text & " and vno=" & TextBox7.Text, con)
        '        Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
        '        If dr.Read() Then
        '            nato = dr.GetValue(0) + 1
        '        Else
        '            nato = 1
        '        End If
        '        dr.Close()
        '    Catch ex As Exception
        '        nato = 1
        '        'Label5.Text = ex.Message
        '    End Try
        'Catch ex As Exception
        '    Label5.Text = ex.Message
        'End Try
        TextBox8.Text = nato
        con.Close()
    End Sub

    

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            con.Open()
            Dim cmd As New SqlCommand("insert into puztime values(" & TextBox1.Text & "," & TextBox6.Text & "," & TextBox3.Text & ",'" & TextBox11.Text & "'," & TextBox8.Text & "," & (25 - TextBox2.Text) & ")", con)
            cmd.ExecuteNonQuery()
            Timer1.Enabled = False
            con.Close()
            Session.Add("examid", TextBox6.Text)
            Session.Add("sqno", TextBox3.Text)
            Response.Redirect("presults.aspx")
        Catch ex As Exception
            Label6.Text = ex.Message
        End Try

    End Sub
End Class
