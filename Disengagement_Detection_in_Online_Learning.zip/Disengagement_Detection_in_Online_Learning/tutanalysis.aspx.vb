﻿Imports System.Data.SqlClient
Imports System
Partial Class tutanalysis
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()
            ListBox3.Items.Clear()
            ListBox4.Items.Clear()
            ListBox5.Items.Clear()
            ListBox6.Items.Clear()
            Dim c1 As Date
            c1 = Calendar1.SelectedDate()
            con.Open()
            Dim cmd As New SqlCommand("select pageid,sdtm,edtm,kwds,fnd from tutvisit where sid=" & TextBox1.Text, con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            While dr.Read()
                Dim d1, d2 As Date
                Dim dd As Integer
                Dim pgid As String
                pgid = dr.GetValue(0)
                d1 = dr.GetValue(1)
                d2 = dr.GetValue(2)
                If d1.ToShortDateString() = c1 And d2.ToShortDateString() = c1 Then
                    ListBox1.Items.Add(pgid)
                    dd = (DateDiff(DateInterval.Second, d1, d2))
                    ListBox2.Items.Add(d1.ToString())
                    ListBox3.Items.Add(d2.ToString())
                    ListBox4.Items.Add(dd.ToString())
                    Dim kwds, fnds As String
                    kwds = dr.GetValue(3)
                    fnds = dr.GetValue(4)
                    Dim kwdsa(), fndsa() As String
                    kwdsa = kwds.Split(":")
                    fndsa = fnds.Split(":")
                    Dim k As Integer
                    For k = 1 To kwdsa.Length - 1
                        ListBox5.Items.Add(kwdsa(k))
                        If fndsa(k) = 0 Then
                            ListBox6.Items.Add("Not Found")
                        Else
                            ListBox6.Items.Add("Found")
                        End If
                    Next
                End If
            End While
            dr.Close()
        Catch ex As Exception

        End Try
        con.Close()
    End Sub
End Class
