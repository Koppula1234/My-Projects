﻿Imports System.Data.SqlClient
Imports System
Partial Class startskilltest
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Dim fg As Integer
    Dim randomvalue As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TextBox1.Text = Session.Item("lsid")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim nexid As Integer
        Try
            con.Open()
            nexid = 10000
            Try
                Dim cmd1 As New SqlCommand("select max(exid) from exam", con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    nexid = dr.GetValue(0) + 1
                Else
                    nexid = 10000
                End If
                dr.Close()
            Catch ex As Exception
                nexid = 10000
                'Label5.Text = ex.Message
            End Try
        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
        con.Close()
        TextBox6.Text = nexid
        TextBox2.Text = 10
        Timer1.Enabled = True
        TextBox3.Text = "1"
        TextBox5.Text = 0
        Dim j, k As Integer
        'randomvalue = CInt(Int((5) * Rnd(5) + 1))
        ListBox1.Items.Clear()
        Dim fg As Integer = 0
        j = 0
        While j < 3
            Dim nv As Integer
            nv = RandomNumber(1000, 1005)
            fg = 0
            For k = 0 To ListBox1.Items.Count - 1
                If (ListBox1.Items(k).Text = nv) Then
                    fg = 1
                End If
            Next
            If (fg = 0) Then
                ListBox1.Items.Add(nv)
                j = j + 1
            End If
        End While
        Try
            con.Open()
            Dim cmd As New SqlCommand("select * from questionaire where qid=" & ListBox1.Items(0).Text, con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            If dr.Read() Then
                TextBox4.Text = dr.GetValue(1)
                RadioButton1.Text = dr.GetValue(3)
                RadioButton2.Text = dr.GetValue(4)
                RadioButton3.Text = dr.GetValue(5)
                RadioButton4.Text = dr.GetValue(6)
            End If

        Catch ex As Exception
            Label6.Text = ex.Message()
        End Try
        con.Close()

        Dim vno As Integer

        Dim nvno As Integer
        Try
            con.Open()
            nvno = 1
            Try
                Dim cmd1 As New SqlCommand("select max(vno) from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    nvno = dr.GetValue(0) + 1
                Else
                    nvno = 1
                End If
                dr.Close()
            Catch ex As Exception
                nvno = 1
                'Label5.Text = ex.Message
            End Try
        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
        TextBox7.Text = nvno
        con.Close()

        Try
            con.Open()
            Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & nvno & ")", con)
            cmd.ExecuteNonQuery()
            Dim cmd2 As New SqlCommand("insert into exam values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",0,1," & nvno & "," & ListBox1.Items(TextBox5.Text).ToString() & ")", con)
            cmd2.ExecuteNonQuery()
            TextBox8.Text = "1"
        Catch ex As Exception
            Label6.Text = ex.Message()
        End Try
        con.Close()
        Button1.Enabled = False
    End Sub

    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        TextBox2.Text = TextBox2.Text - 1
        If TextBox2.Text = 0 Then
            'Try
            '    con.Open()
            '    Dim cmd5 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
            '    Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
            '    If dr5.Read() Then
            '        dr5.Close()
            '        Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
            '        Dim stat As Integer = cmd.ExecuteNonQuery()
            '        If stat > 0 Then
            '            Label6.Text = "Time"
            '        End If
            '        Dim cmd11 As New SqlCommand("update revise set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & ListBox1.SelectedItem.Text, con)
            '        Dim stat1 As Integer = cmd11.ExecuteNonQuery()
            '    Else
            '        dr5.Close()
            '        Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
            '        cmd.ExecuteNonQuery()
            '    End If
            'Catch ex As Exception
            '    Label6.Text = ex.Message
            'End Try
            'con.Close()

            If TextBox5.Text <= 2 Then
                Try
                    con.Open()
                    Dim cmd5 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                    Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                    If dr5.Read() Then
                        dr5.Close()
                        Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                        Dim stat As Integer = cmd.ExecuteNonQuery()
                        If stat > 0 Then
                            Label6.Text = "Time"
                        End If
                    Else
                        dr5.Close()
                        Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
                        cmd.ExecuteNonQuery()
                    End If
                    'Timer1.Enabled = False
                    'Response.Redirect("results.aspx")
                Catch ex As Exception
                    Label6.Text = ex.Message
                End Try
                con.Close()
            Else
                Try
                    con.Open()
                    Dim cmd5 As New SqlCommand("select * from revise where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text, con)
                    Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                    If dr5.Read() Then
                        dr5.Close()
                        Dim cmd As New SqlCommand("update revise set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text, con)
                        Dim stat As Integer = cmd.ExecuteNonQuery()
                        If stat > 0 Then
                            Label6.Text = "Time"
                        End If
                    Else
                        dr5.Close()
                        Dim cmd As New SqlCommand("insert into revise values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox10.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
                        cmd.ExecuteNonQuery()
                    End If
                    'Timer1.Enabled = False
                    'Response.Redirect("results.aspx")
                Catch ex As Exception
                    Label6.Text = ex.Message
                End Try
            End If

            Timer1.Enabled = False
            Response.Redirect("results.aspx")

        End If

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            con.Open()
            Dim cans As Integer = 0
            If RadioButton1.Checked = True Then
                cans = 1
            Else
                If RadioButton2.Checked = True Then
                    cans = 2
                Else
                    If RadioButton3.Checked = True Then
                        cans = 3
                    Else
                        If RadioButton4.Checked = True Then
                            cans = 4
                        Else
                            cans = 0
                        End If
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
        con.Close()
        If TextBox5.Text = 2 Then
            con.Open()
            Dim cmd6 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
            Dim dr6 As SqlDataReader = cmd6.ExecuteReader(Data.CommandBehavior.SingleRow)
            If dr6.Read() Then
                dr6.Close()
                Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            End If
            con.Close()
        End If

        If TextBox5.Text < 2 Then
            con.Open()
            Dim cmd6 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
            Dim dr6 As SqlDataReader = cmd6.ExecuteReader(Data.CommandBehavior.SingleRow)
            If dr6.Read() Then
                dr6.Close()
                Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            End If
            con.Close()

            TextBox3.Text = TextBox3.Text + 1
            TextBox7.Text = "1"
            TextBox8.Text = "1"
            Label6.Text = ""
            TextBox5.Text = TextBox5.Text + 1
            Try
                con.Open()

                Dim cmd As New SqlCommand("select * from questionaire where qid=" & ListBox1.Items(TextBox5.Text).Text, con)
                Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                Dim i As Integer = 1
                If dr.Read() Then
                    TextBox4.Text = dr.GetValue(1)
                    RadioButton1.Text = dr.GetValue(3)
                    RadioButton2.Text = dr.GetValue(4)
                    RadioButton3.Text = dr.GetValue(5)
                    RadioButton4.Text = dr.GetValue(6)
                End If
                dr.Close()

                Dim cmd2 As New SqlCommand("insert into exam values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",0,1,1" & "," & ListBox1.Items(TextBox5.Text).ToString() & ")", con)
                cmd2.ExecuteNonQuery()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()

            Try
                con.Open()
                Dim fg As Integer
                Dim cmd5 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr5.Read() Then
                    dr5.Close()
                    Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                    cmd.ExecuteNonQuery()
                Else
                    dr5.Close()
                    Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
                    cmd.ExecuteNonQuery()
                End If
            Catch ex As Exception
                Label6.Text = ex.Message
            End Try
            con.Close()
        Else
            Label6.Text = "You have reached the last question"
        End If
        

    End Sub

    Public Function RandomNumber(ByVal MaxNumber As Integer, Optional ByVal MinNumber As Integer = 0) As Integer

        'initialize random number generator
        Dim r As New Random(System.DateTime.Now.Millisecond)

        'if passed incorrect arguments, swap them
        'can also throw exception or return 0

        If MinNumber > MaxNumber Then
            Dim t As Integer = MinNumber
            MinNumber = MaxNumber
            MaxNumber = t
        End If

        Return r.Next(MinNumber, MaxNumber)

    End Function

    Protected Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If TextBox5.Text >= 2 Then
            '
            Try
                con.Open()
                TextBox5.Text = TextBox5.Text + 1

                Dim cmd5 As New SqlCommand("select * from revise where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text & " and tid=" & TextBox9.Text - 1, con)
                Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr5.Read() Then
                    dr5.Close()
                    Dim cmd As New SqlCommand("update revise set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text & " and tid=" & TextBox9.Text - 1, con)
                    Dim stat As Integer = cmd.ExecuteNonQuery()
                    If stat > 0 Then
                        Label6.Text = "Time"
                    End If
                    Dim cmd9 As New SqlCommand("insert into revise values(" & TextBox6.Text & "," & TextBox1.Text & "," & ListBox1.Items(ListBox1.SelectedIndex).Text & ",'" & Date.Now & "',' '," & TextBox9.Text & ")", con)
                    cmd9.ExecuteNonQuery()
                    TextBox9.Text = TextBox9.Text + 1
                    TextBox10.Text = ListBox1.Items(ListBox1.SelectedIndex).Text
                Else
                    dr5.Close()
                    Dim cmd As New SqlCommand("insert into revise values(" & TextBox6.Text & "," & TextBox1.Text & "," & ListBox1.Items(ListBox1.SelectedIndex).Text & ",'" & Date.Now & "',' '," & TextBox9.Text & ")", con)
                    cmd.ExecuteNonQuery()
                    TextBox9.Text = TextBox9.Text + 1
                    TextBox10.Text = ListBox1.Items(ListBox1.SelectedIndex).Text
                End If
                'Timer1.Enabled = False
                'Response.Redirect("results.aspx")
            Catch ex As Exception
                Label6.Text = ex.Message
            End Try
            con.Close()
            '
            RadioButton1.Checked = False
            RadioButton2.Checked = False
            RadioButton3.Checked = False
            RadioButton4.Checked = False
            Try
                con.Open()

                Dim cmd5 As New SqlCommand("update exam set vno=vno+1 where aqno=" & ListBox1.Items(ListBox1.SelectedIndex).Text & " and exid=" & TextBox6.Text, con)
                Dim stat As Integer = cmd5.ExecuteNonQuery()
                If (stat > 0) Then
                    Label6.Text = "Updated"
                End If
                Dim cmd6 As New SqlCommand("select vno from exam where aqno=" & ListBox1.Items(ListBox1.SelectedIndex).Text & " and exid=" & TextBox6.Text, con)
                Dim dr6 As SqlDataReader = cmd6.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                If dr6.Read() Then
                    TextBox7.Text = dr6.GetValue(0)
                End If
                dr6.Close()


                Dim cmd7 As New SqlCommand("select atno from exam where aqno=" & ListBox1.Items(ListBox1.SelectedIndex).Text & " and exid=" & TextBox6.Text, con)
                Dim dr7 As SqlDataReader = cmd7.ExecuteReader(Data.CommandBehavior.SequentialAccess)
                If dr7.Read() Then
                    TextBox8.Text = dr7.GetValue(0) + 1
                End If
                dr7.Close()

                Dim cmd As New SqlCommand("select * from questionaire where qid=" & ListBox1.Items(ListBox1.SelectedIndex).Text, con)
                Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr.Read() Then
                    TextBox4.Text = dr.GetValue(1)
                    RadioButton1.Text = dr.GetValue(3)
                    RadioButton2.Text = dr.GetValue(4)
                    RadioButton3.Text = dr.GetValue(5)
                    RadioButton4.Text = dr.GetValue(6)
                End If
                dr.Close()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()
            con.Open()
            Dim ans As Integer
            'Label6.Text = ListBox1.Items(ListBox1.SelectedIndex).Text
            Dim cmd2 As New SqlCommand("select * from exam where aqno=" & ListBox1.Items(ListBox1.SelectedIndex).Text & " and exid=" & TextBox6.Text, con)
            Dim dr2 As SqlDataReader = cmd2.ExecuteReader(Data.CommandBehavior.SingleRow)
            'Label6.Text = dr2.Read()
            If dr2.Read() Then
                TextBox3.Text = dr2.GetValue(2)
                ans = dr2.GetValue(3)
            End If
            dr2.Close()
            If (ans = 1) Then
                RadioButton1.Checked = True
            Else
                If (ans = 2) Then
                    RadioButton2.Checked = True
                Else
                    If (ans = 3) Then
                        RadioButton3.Checked = True
                    Else
                        If (ans = 4) Then
                            RadioButton4.Checked = True
                        Else
                            RadioButton1.Checked = False
                            RadioButton2.Checked = False
                            RadioButton3.Checked = False
                            RadioButton4.Checked = False
                        End If
                    End If
                End If
            End If
            'Label6.Text = ans
            con.Close()



        End If
    End Sub

    
    Protected Sub RadioButton1_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("update exam set ans=1,atno=" & TextBox8.Text & " where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()
        End If
        incr_visit()
    End Sub

    Protected Sub RadioButton2_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("update exam set ans=2,atno=" & TextBox8.Text & " where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()
            incr_visit()
        End If
    End Sub

    Public Sub incr_visit()
        Dim nato As Integer
        Try
            con.Open()
            nato = 1
            Try
                Dim cmd1 As New SqlCommand("select max(atno) from exam where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text & " and vno=" & TextBox7.Text, con)
                Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)
                If dr.Read() Then
                    nato = dr.GetValue(0) + 1
                Else
                    nato = 1
                End If
                dr.Close()
            Catch ex As Exception
                nato = 1
                'Label5.Text = ex.Message
            End Try
        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
        TextBox8.Text = nato
        con.Close()
    End Sub

    Protected Sub RadioButton3_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("update exam set ans=3,atno=" & TextBox8.Text & " where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()
        End If
        incr_visit()
    End Sub

    Protected Sub RadioButton4_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            Try
                con.Open()
                Dim cmd As New SqlCommand("update exam set ans=4,atno=" & TextBox8.Text & " where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Label6.Text = ex.Message()
            End Try
            con.Close()
        End If
        incr_visit()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox5.Text <= 2 Then
            Try
                con.Open()
                Dim cmd5 As New SqlCommand("select * from timeinfo where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr5.Read() Then
                    dr5.Close()
                    Dim cmd As New SqlCommand("update timeinfo set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and qno=" & TextBox3.Text, con)
                    Dim stat As Integer = cmd.ExecuteNonQuery()
                    If stat > 0 Then
                        Label6.Text = "Time"
                    End If
                Else
                    dr5.Close()
                    Dim cmd As New SqlCommand("insert into timeinfo values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox3.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
                    cmd.ExecuteNonQuery()
                End If
                Timer1.Enabled = False
                Session.Add("examid", TextBox6.Text)
                Response.Redirect("results.aspx")
            Catch ex As Exception
                Label6.Text = ex.Message
            End Try
            con.Close()
        Else
            Try
                con.Open()
                Dim cmd5 As New SqlCommand("select * from revise where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text, con)
                Dim dr5 As SqlDataReader = cmd5.ExecuteReader(Data.CommandBehavior.SingleRow)
                If dr5.Read() Then
                    dr5.Close()
                    Dim cmd As New SqlCommand("update revise set edtm='" & Date.Now & "' where exid=" & TextBox6.Text & " and sid=" & TextBox1.Text & " and aqno=" & TextBox10.Text, con)
                    Dim stat As Integer = cmd.ExecuteNonQuery()
                    If stat > 0 Then
                        Label6.Text = "Time"
                    End If
                Else
                    dr5.Close()
                    Dim cmd As New SqlCommand("insert into revise values(" & TextBox6.Text & "," & TextBox1.Text & "," & TextBox10.Text & ",'" & Date.Now & "',' '," & TextBox7.Text & ")", con)
                    cmd.ExecuteNonQuery()
                End If
                Timer1.Enabled = False
                Session.Add("examid", TextBox6.Text)
                Response.Redirect("results.aspx")

            Catch ex As Exception
                Label6.Text = ex.Message
            End Try
        End If
    End Sub
End Class
