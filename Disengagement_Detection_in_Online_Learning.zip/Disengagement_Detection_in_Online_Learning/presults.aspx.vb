﻿Imports System.Data.SqlClient
Imports System
Partial Class presults
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim texid As Integer
        texid = Session.Item("examid")
        Dim sqno As Integer
        sqno = Session.Item("sqno")
        Try
            con.Open()
            'Response.Write("select qid,pcans,ans from puztime,puzzle where pzid=" & texid & " and qno=qid and qno=" & sqno)
            Dim cmd As New SqlCommand("select qid,pcans,ans from puztime,puzzle where pzid=" & texid & " and qno=qid and qno=" & sqno, con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            Dim ncans As Integer = 0
            While dr.Read()
                If dr.GetValue(1) = dr.GetValue(2) Then
                    ncans = ncans + 1
                End If
            End While
            dr.Close()
            If ncans >= 1 Then
                Response.Write("<h3>RESULT<hr><b><font color=red>Passed")
            Else
                Response.Write("<h3>RESULT<hr><b><font color=red>Better Luck Next Time")
            End If
        Catch ex As Exception

        End Try

        Dim cmd2 As New SqlCommand("select distinct qno from timeinfo where exid=" & texid, con)
        Dim dr2 As SqlDataReader = cmd2.ExecuteReader(Data.CommandBehavior.SequentialAccess)

        con.Close()
    End Sub
End Class
