﻿Imports System.Data.SqlClient
Partial Class PostQuest
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Data Source=SYSTEM;Initial Catalog=disdetdb;User ID=sa;Password=a")
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim nqno As Integer
        Try
            con.Open()
            nqno = 1000
            Dim cmd1 As New SqlCommand("select max(qid) from questionaire", con)
            Dim dr As SqlDataReader = cmd1.ExecuteReader(Data.CommandBehavior.SingleResult)

            Try
                If dr.Read() Then
                    nqno = dr.GetValue(0) + 1
                Else
                    nqno = 1000
                End If

            Catch ex As Exception
                nqno = 1000
                'Label5.Text = ex.Message
            End Try
            dr.Close()
            Dim cmd2 As New SqlCommand("insert into questionaire values(" & nqno & ",'" & TextBox1.Text & "','" & DropDownList1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "')", con)
            cmd2.ExecuteNonQuery()

            Label9.Text = "Question Updated Successfully with ID " & nqno

        Catch ex As Exception
            Label9.Text = "Question with this ID already exists! Try Another." & ex.Message
        End Try
        con.Close()
        TextBox1.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
    End Sub
End Class
