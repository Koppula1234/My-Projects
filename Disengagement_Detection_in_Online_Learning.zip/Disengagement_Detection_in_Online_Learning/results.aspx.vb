﻿Imports System.Data.SqlClient
Imports System
Partial Class results
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim texid As Integer
        texid = Session.Item("examid")
        Try
            con.Open()
            Dim cmd As New SqlCommand("select qid,cans,ans from exam,questionaire where exid=" & texid & " and qid=aqno ", con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            Dim ncans As Integer = 0
            While dr.Read()
                If dr.GetValue(1) = dr.GetValue(2) Then
                    ncans = ncans + 1
                End If
            End While
            dr.Close()
            If ncans >= 2 Then
                Response.Write("<h3>RESULT<hr><b><font color=red>Passed")
            Else
                Response.Write("<h3>RESULT<hr><b><font color=red>Better Luck Next Time")
            End If
        Catch ex As Exception

        End Try

        con.Close()
    End Sub
End Class
