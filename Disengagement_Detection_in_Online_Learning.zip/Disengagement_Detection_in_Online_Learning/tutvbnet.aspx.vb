﻿Imports System.Data.SqlClient
Partial Class tutvbnet
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("data source=system;initial catalog=disdetdb;user id=sa;password=a")
    Dim nvno As Integer
    Dim tdt As Date
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim srch As String
        srch = TextBox1.Text.Trim()
        Try
            con.Open()
            Dim cmd As New SqlCommand("select * from keywords", con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.SequentialAccess)
            Dim tst As String
            Dim tokens() As String
            ListBox1.Items.Clear()
            While dr.Read()
                tst = dr.GetValue(0)
                tokens = tst.Split(":")
                Dim i As Integer
                For i = 0 To tokens.Length - 1
                    If (srch = tokens(i)) Then
                        ListBox1.Items.Add(dr.GetValue(1))
                    End If
                Next
            End While
            dr.Close()
            Dim fnd As Integer
            If ListBox1.Items.Count > 0 Then
                fnd = 1
            Else
                fnd = 0
            End If
            Dim cmd2 As New SqlCommand("update tutvisit set kwds=kwds + ':' + '" & TextBox1.Text & "',fnd=fnd+':'+'" & fnd & "' where pageid='" & HiddenField1.Value & "' and sdtm=(select exid from examid)", con)
            cmd2.ExecuteNonQuery()

        Catch ex As Exception

        End Try
        con.Close()
    End Sub


    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not Page.IsPostBack() Then
            Dim sid As String
            sid = Session.Item("lsid")
            Dim dt As String = Date.Now
            'Dim tm As Date = Date.Now.ToShortTimeString()
            Try
                con.Open()
                Dim cmd2 As New SqlCommand("select max(vno) from tutvisit where pageid='" & HiddenField1.Value & "'", con)
                Dim dr2 As SqlDataReader = cmd2.ExecuteReader(Data.CommandBehavior.SingleResult)
                Try
                    If dr2.Read() Then
                        nvno = dr2.GetValue(0) + 1
                    End If
                Catch ex As Exception
                    nvno = 1
                End Try
                dr2.Close()
                Dim cmd As New SqlCommand("insert into tutvisit values('" & HiddenField1.Value & "'," & sid & ",'" & dt & "',' ',' ',' '," & nvno & ")", con)
                cmd.ExecuteNonQuery()
                Dim cmd21 As New SqlCommand("delete from examid", con)
                cmd21.ExecuteNonQuery()
                Dim cmd22 As New SqlCommand("insert into examid values('" & dt & "')", con)
                cmd22.ExecuteNonQuery()
                Session.Add("hf", HiddenField1.Value)
            Catch ex As Exception

            End Try
            con.Close()

        End If
    End Sub

    Public Sub updateedtm()
        Dim sid As String
        sid = Session.Item("lsid")
        Dim dt As String = Date.Now
        'Dim tm As Date = Date.Now.ToShortTimeString()

        Try
            Dim hf As String
            hf = Session.Item("hf")
            con.Open()
            Dim cmd As New SqlCommand("update tutvisit set edtm='" & dt & "' where pageid='" & hf & "' and sdtm=(select exid from examid)", con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        con.Close()
    End Sub

    Protected Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        'updateedtm()
        Response.Redirect(ListBox1.SelectedItem().ToString())
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub form1_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles form1.Unload
        updateedtm()
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        updateedtm()
    End Sub
End Class
