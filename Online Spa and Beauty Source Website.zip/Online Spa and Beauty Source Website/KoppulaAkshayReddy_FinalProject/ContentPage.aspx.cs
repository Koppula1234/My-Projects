﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Assignment_3_Default2 : System.Web.UI.Page
{
    public string s_head = "SPA and Beauty Source";
    public string hou = "Houston, TX";
    public string dis_para = "Refresh Discount SPA Source";
    public class Summary
    {
        private readonly string _name;
        private readonly string _phoneNumber;
        private readonly string _contact;
        private readonly string _message;

        public Summary(string name, string phoneNumber, string contact, string message)
        {
            _name = name;
            _phoneNumber = phoneNumber;
            _contact = contact;
            _message = message;
        }

        public override string ToString()
        {

            return String.Format("<br/>{0}<br />{1}<br />{2}<br/>{3}", _name, _phoneNumber, _contact, HttpUtility.HtmlEncode(_message));
        }
    }
    /*protected void Page_PreInit(object sender, EventArgs e)
    {
        this.Theme = "Bluish_Reddish";
    }*/
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string usermessage = string.Empty;
        try
        {
            ValidateMsgTextfield();
            Summary s1 = new Summary(tb1.Text, tb2.Text, DropDownList1.Text, tb3.Text);
            usermessage = "Selected details are:" + s1.ToString();
        }
        catch (Exception ex)
        {
            usermessage = ex.Message;
        }
        finally
        {
            Label2.Text = usermessage;
        }
    }

    private void ValidateMsgTextfield()
    {
        if (tb3.Text.Length < 10)
        {
            throw new Exception("Your message must have 10 or more characters");
        }
    }
    private void Page_PreInit(object sender, EventArgs e)
    {
        var Themes = Request.Cookies.Get("ThemeAkshay");
        if (Themes != null)
        {
            Page.Theme = Themes.Value;
        }
    }
}