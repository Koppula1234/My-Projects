﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpecialProductList : System.Web.UI.Page
{
    AdventureWorks2012_DataEntities entity1 = new AdventureWorks2012_DataEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public IQueryable<Product> ListView1_GetData()
    {
        return from p in entity1.Products
               where p.DiscontinuedDate == null
               select p;
    }
}