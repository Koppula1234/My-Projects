﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Assignment_3_Default : System.Web.UI.MasterPage
{
    public string s_head = "SPA and Beauty Source";
    public string hou = "Houston, TX";
    public string dis_para = "Refresh Discount SPA Source";
    private const int StartHour = 9;
    private const int EndHour = 6;
    private const DayOfWeek StartWeek = DayOfWeek.Monday;
    private const DayOfWeek EndWeek = DayOfWeek.Friday;
    protected void Page_Load(object sender, EventArgs e)
    {
        Random r = new Random();
        Label1.Text = "(" + r.Next(10) + r.Next(10) + r.Next(10) + ")" + " " + r.Next(10) + r.Next(10) + r.Next(10) + "-" + r.Next(10) + r.Next(10) + r.Next(10) + r.Next(10);
        Label3.Text = String.Format("{0}-{1}, {2} A.M-{3} P.M", StartWeek, EndWeek, StartHour, EndHour);
        String lb4, lb5;
        if (DateTime.Now.ToString("ddd") == "Sun")
        {
            lb5 = "Closed";
            lb4 = "";
        }
        else if (DateTime.Now.Hour >= 18 || DateTime.Now.Hour <= 09 )
        {
            lb5 = "Closed right now";
            lb4 = "";
        }
        else
        {
            lb4 = "Opened right now";
            lb5 = "";
        }

        Label4.Text = lb4;
        Label5.Text = lb5;

        if (!Page.IsPostBack)
        {
            var cookie = Request.Cookies.Get("ThemeAkshay");
            if (cookie == null)
            {
                ThemeAkshay.SelectedValue = Page.Theme;
            }
            else
            {
                ThemeAkshay.SelectedValue = cookie.Value;
            }
        }

   }
   protected void ThemeAkshay_SelectedIndexChanged(object sender, EventArgs e)
    {
        var Themes = new HttpCookie("ThemeAkshay");
        Themes.Expires = DateTime.Now.AddMonths(1);
        Themes.Value = ThemeAkshay.SelectedValue;
        Response.Cookies.Add(Themes);
        Response.Redirect(Request.Url.ToString());
    }
}
