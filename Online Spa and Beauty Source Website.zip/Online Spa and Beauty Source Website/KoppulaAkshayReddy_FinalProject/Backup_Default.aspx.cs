﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    public string s_head = "SPA and Beauty Source";
    public string hou = "Houston, TX";
    public string dis_para = "Refresh Discount SPA Source";
    private const int StartHour = 9;
    private const int EndHour = 6;
    private const DayOfWeek StartWeek = DayOfWeek.Monday;
    private const DayOfWeek EndWeek = DayOfWeek.Friday;
    
    public class Summary
    {
        private readonly string _name;
        private readonly string _phoneNumber;
        private readonly string _contact;
        private readonly string _message;
        
        public Summary(string name, string phoneNumber, string contact, string message)
        {
            _name = name;
            _phoneNumber = phoneNumber;
            _contact = contact;
            _message = message;
        }

        public override string ToString()
        {
           
            return String.Format("{0}<br />{1}<br />{2}<br/>{3}", _name, _phoneNumber, _contact, HttpUtility.HtmlEncode(_message));
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        Random r = new Random();
        Label1.Text = "(" + r.Next(10) + r.Next(10) + r.Next(10) + ")" + " " + r.Next(10) + r.Next(10) + r.Next(10) + "-" + r.Next(10) + r.Next(10) + r.Next(10) + r.Next(10);
        Label3.Text = String.Format("{0}-{1}, {2} A.M-{3} P.M", StartWeek, EndWeek, StartHour, EndHour);
        String lb4, lb5;
        if (DateTime.Now.ToString("ddd") == "Sun")
        {
            lb5 = "Closed";
            lb4 = "";
        }
        else if (DateTime.Now.Hour >= 18 || DateTime.Now.Hour <= 09 )
        {
            lb5 = "Closed right now";
            lb4 = "";
        }
        else
        {
            lb4 = "Opened right now";
            lb5 = "";
        }

        Label4.Text = lb4;
        Label5.Text = lb5;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Summary s1 = new Summary(tb1.Text,tb2.Text,DropDownList1.Text,tb3.Text);

        Label2.Text = s1.ToString();
    }
}
