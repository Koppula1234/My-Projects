﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Controls_ProductListViewControl : System.Web.UI.UserControl
{
    AdventureWorks2012_DataEntities entity = new AdventureWorks2012_DataEntities();
    public IEnumerable<int> ProductIDs { get; set; }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public IEnumerable<int> ProductIds;
    public IQueryable ListView1_GetData()
    {
        IQueryable<Product> values = null;
        if (ProductIDs != null && ProductIDs.Count() > 0)
        {
            values = from p in entity.Products
                     where ProductIDs.Contains(p.ProductID) && p.DiscontinuedDate == null
                     orderby p.Name
                     select p;
        }

        if (values == null)
        {
            values = Enumerable.Empty<Product>().AsQueryable();
        }

        return values;
    }
}