﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Entity.Validation;
using System.Text;
using System.Data.Entity.Infrastructure;

public partial class SpecialOffersEF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    
    AdventureWorks2012_DataEntities myEntities = new AdventureWorks2012_DataEntities();
    public IQueryable<SpecialOffer> GridView1_GetData()
    {
        var spoffers = from offers in myEntities.SpecialOffers
                   where offers.ModifiedDate > new DateTime(2000,1,1)
                   select offers;
        return spoffers;
    }
    public void GridView1_UpdateItem(SpecialOffer c)
    {
        SpecialOffer SpecialOffer_update = null;
        AdventureWorks2012_DataEntities myEntities = new AdventureWorks2012_DataEntities();
        SpecialOffer_update = myEntities.SpecialOffers.Find(c.SpecialOfferID);
        TryUpdateModel(SpecialOffer_update);
        if (ModelState.IsValid)
        {
            myEntities.SaveChanges();
        }
        Response.Redirect("SpecialOffersEF.aspx");
    }
    public void GridView1_DeleteItem(SpecialOffer c)
    {
        
            var data = from item in myEntities.SpecialOffers
                       where item.SpecialOfferID == c.SpecialOfferID
                       select item;

            foreach (var p in data.ToList())
            {
                p.ModifiedDate = new DateTime(2000, 1, 1);
            }

            myEntities.SaveChanges();
        
    }
    public void DetailsView1_InsertItem()
    {
        SpecialOffer spl = new SpecialOffer();
        TryUpdateModel(spl);
                spl.ModifiedDate = DateTime.Now;
                myEntities.SpecialOffers.Add(spl);
                spl.rowguid = Guid.NewGuid();
                try
                {
                    myEntities.SaveChanges();
                }
        
        catch (DbEntityValidationException ex)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var failure in ex.EntityValidationErrors)
            {
                sb.AppendFormat("{0} failed validation\n", failure.Entry.Entity.GetType());
                foreach (var error in failure.ValidationErrors)
                {
                    sb.AppendFormat("- {0} : {1}", error.PropertyName, error.ErrorMessage);
                    sb.AppendLine();
                }
            }

            throw new DbEntityValidationException(
                "Entity Validation Failed - errors follow:\n" +
                sb.ToString(), ex
            );
        }
        Response.Redirect("SpecialOffersEF.aspx");

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int specialOfferID = Convert.ToInt32(GridView1.SelectedValue);
        var SPoffers = from item in myEntities.SpecialOffers
                   where item.SpecialOfferID == specialOfferID
                   select item;
        DetailView2.DataSource = SPoffers.ToList();
        DetailView2.DataBind();
    }    
}