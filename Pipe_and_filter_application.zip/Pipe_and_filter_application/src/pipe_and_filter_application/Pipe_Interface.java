package pipe_and_filter_application;

public interface Pipe_Interface {
    public boolean put(Object obj);
    public Object get() throws InterruptedException;
}
