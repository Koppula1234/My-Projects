package pipe_and_filter_application;


public class Pipe_and_filter_application {

    public static void main(String[] args) {
        
        Pipe_Interface pipe = new PipeImplementation();
 
        Thread wordGenerator = new WordSortGenerator(pipe);
        Thread wordSortFilter = new WordSortFilter(pipe);
        
        wordGenerator.start();
        wordSortFilter.start();
    }
    
}
