package pipe_and_filter_application;
import java.io.*;
import java.util.*;

public class WordSortFilter extends Thread{
   private Pipe_Interface pipe = null;
    private List<String> wordList = new ArrayList<String>();
 
    public WordSortFilter(Pipe_Interface _pipe) {
        pipe = _pipe;
    }
 
    public void run() {
        String word = null;
 
        try {
            while ((word = (String) pipe.get()) != null){
                String newword = word.toLowerCase();
                if(!wordList.contains(newword)){
                wordList.add(newword);
                }
            }
                
        } catch (InterruptedException intrtex) {}
        for (int i = 0; i < wordList.size()-1; i++) {
            for (int j = i+1; j < wordList.size(); j++) {
                if(wordList.get(i).charAt(0) > wordList.get(j).charAt(0)){
                    String temp = wordList.get(i);
                    wordList.set(i, wordList.get(j));
                    wordList.set(j, temp);  
                }
            }
        }
 
        try {
            FileWriter fw = new FileWriter("sortedwords.txt");
            for (String s : wordList) {
                System.out.print(s + " ");
                fw.write(s + " ");
            }
            fw.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        }
 
    } 
}
