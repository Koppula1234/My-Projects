package pipe_and_filter_application;
import java.io.*;

public class WordSortGenerator extends Thread{
    private Pipe_Interface pipe = null;
 
    public WordSortGenerator(Pipe_Interface _pipe) {
        pipe = _pipe;
    }
 
    public void run() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("pftest.txt"));
            String[] word = br.readLine().split("[,.!\\s]+");
            for (int i = 0; i < word.length; i++) {
                pipe.put(word[i]);
            }
            pipe.put(null);
            br.close();
        }catch (IOException ioex) {
            ioex.printStackTrace();
        }
    }
}
